A method returns a method of its parent class.
