from to_import import MyClass

a = MyClass()
a.func()
