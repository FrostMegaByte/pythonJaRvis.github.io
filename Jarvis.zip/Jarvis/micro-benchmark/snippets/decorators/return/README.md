The decorator is a function call.
