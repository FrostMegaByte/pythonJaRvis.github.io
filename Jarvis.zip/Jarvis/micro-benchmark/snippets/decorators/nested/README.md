A function defined inside another function's context serves as a decorator.
