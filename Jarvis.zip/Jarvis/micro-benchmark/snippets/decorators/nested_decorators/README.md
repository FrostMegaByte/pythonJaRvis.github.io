A function has two decorators, meaning that the first calls the second and the
second calls the function.
