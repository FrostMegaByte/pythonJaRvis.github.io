def func1():
    pass

def func2():
    pass

def func3():
    pass

def func4():
    pass

a, *b, c = func1, func2, func3, func4

a()
b[0]()
b[1]()
c()
