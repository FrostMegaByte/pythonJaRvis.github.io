Two variables are assigned a value via a tuple assignment.
