def func(a):
    return a + 1

ls = [func(a) for a in range(10)]
