A comprehension calls two functions.
