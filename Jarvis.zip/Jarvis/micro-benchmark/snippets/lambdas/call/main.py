x = lambda x: x + 1

x(1)
