def func():
    return (lambda x: x + 1)

y = func()
y()
