A parameter is passed to a lambda and the lambda calls it.
