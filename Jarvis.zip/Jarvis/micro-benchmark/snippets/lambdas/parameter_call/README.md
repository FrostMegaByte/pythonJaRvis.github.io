A lambda is passed as a parameter and that parameter is called.
