.. _Anchor For ExampleRSTFile:

#################
Example .rst File
#################

If you work with edX documentation source files, you might find this file
helpful as a reference. This file contains examples of .rst formatting.

Explanations and more context for each type of element are provided in
:ref:`Work with edX Documentation Source Files`.

This file covers the following topics.

