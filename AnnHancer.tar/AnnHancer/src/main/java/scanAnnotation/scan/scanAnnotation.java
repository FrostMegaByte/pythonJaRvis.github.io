package scanAnnotation.scan;

import dataStructure.scanClass;
import soot.SootClass;
import soot.SootMethod;

import java.util.List;

public interface scanAnnotation {

    public void scanJar();
    public void scanCommonJar(String jarPath);
}

