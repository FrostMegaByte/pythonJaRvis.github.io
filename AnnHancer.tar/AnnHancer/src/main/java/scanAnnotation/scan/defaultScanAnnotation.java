package scanAnnotation.scan;


import base.config.Config;
import base.util.JsonUtil;
import com.alibaba.fastjson.JSONObject;
import dataStructure.scanAnnotationClass;
import dataStructure.scanClass;
import soot.Scene;
import soot.SootClass;
import soot.SootMethod;
import scanAnnotation.soot.sootInvoker;
import soot.tagkit.AnnotationTag;
import soot.tagkit.Tag;
import soot.tagkit.VisibilityAnnotationTag;
import soot.util.Chain;

import java.util.*;

public class defaultScanAnnotation implements scanAnnotation {
    List<scanClass> scanClasses = new ArrayList<>();
    List<scanAnnotationClass> scanAnnotationClasses = new ArrayList<>();
    Map<String,scanClass> map = new HashMap<>();

    /**
     *
     * @return
     */
    @Override
    public void scanJar(){
        JSONObject object = JsonUtil.readJsonObject(Config.CLASSIFICATION_PATH);

        List<String> jars = new ArrayList<>();
        for(String jar : Config.JAR_PATH){
            jars.add(jar);
        }
        sootInvoker.preProcess(jars);
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        Chain<SootClass> chain = Scene.v().getClasses();

        for(SootClass sootClass : chain){
            //
//            if (!sootClass.getName().startsWith("BOOT-INF.classes")) {
//                continue;
//            }

            //
            for(SootClass sc : sootClass.getInterfaces()){
                if(sc.getName().equals("java.lang.annotation.Annotation")){
                    scanAnnotationClass sac = new scanAnnotationClass(sootClass);
                    sac.setAnnotationInfo(object);
                    scanAnnotationClasses.add(sac);
                }
            }
            scanClass sc = new scanClass(sootClass);
            sc.setAnnotations();
            sc.setInterfaceName();
            scanClasses.add(sc);
            map.put(sootClass.getName(),sc);
        }
        findParents();
    }

    /**
     *
     * @param jarPath
     * @return
     */
    @Override
    public void scanCommonJar(String jarPath){
        JSONObject object = JsonUtil.readJsonObject(Config.CLASSIFICATION_PATH);

        List<String> jars = new ArrayList<>();
        jars.add(jarPath);
        sootInvoker.preProcess(jars);
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        Chain<SootClass> chain = Scene.v().getApplicationClasses();

        for(SootClass sootClass : chain){
            for(SootClass sc : sootClass.getInterfaces()){
                if(sc.getName().equals("java.lang.annotation.Annotation")){
                    scanAnnotationClass sac = new scanAnnotationClass(sootClass);
                    sac.setAnnotationInfo(object);
                    scanAnnotationClasses.add(sac);
                }
            }
            scanClass sc = new scanClass(sootClass);
            sc.setAnnotations();
            scanClasses.add(sc);
        }
    }

    public List<scanClass> getScanClasses(){
        return this.scanClasses;
    }

    public Map<String,scanClass> getMap(){
        return this.map;
    }

    public List<scanAnnotationClass> getScanAnnotationClasses(){
        return this.scanAnnotationClasses;
    }

    public Map<String,List<String>> getProjectAnnotationMap(){
        Map<String,List<String>> map = new HashMap<>();
        for(scanAnnotationClass sac : scanAnnotationClasses){
            if(!map.containsKey(sac.getAnnotationName())){
                map.put(sac.getAnnotationName(),new ArrayList<>());
            }
            map.get(sac.getAnnotationName()).add(sac.getAnnotationType());
        }
        return map;
    }

    /**
     *
     *
     */
    private void findParents(){
        Map<String,SootClass> childrenToFather = new HashMap<>();
        for(scanClass sc : scanClasses){
            if(!sc.hasSuperClass()){
                continue;
            }
            SootClass father = sc.getSuperClass();
            childrenToFather.put(sc.getName(),father);
        }

        for(scanClass sc : scanClasses){
            List<String> parents = new ArrayList<>();
            Queue<String> queue = new LinkedList<>();
            queue.add(sc.getName());
            while(!queue.isEmpty()){
                String className = queue.poll();
                if(!childrenToFather.containsKey(className)){
                    continue;
                }
                String fatherName = childrenToFather.get(className).getName();
                String longFatherName = "BOOT-INF.classes." + fatherName;
                parents.add(fatherName);
                if(childrenToFather.containsKey(fatherName)){
                    queue.add(fatherName);
                }
                if(childrenToFather.containsKey(longFatherName)){
                    queue.add(longFatherName);
                }
            }
            sc.setParents(parents);
        }
    }
}




