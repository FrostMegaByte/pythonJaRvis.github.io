package scanAnnotation.soot;

import base.config.Config;
import soot.G;
import soot.options.Options;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class sootInvoker {
    /**
     * soot
     * @param jarPath
     */
    public static void preProcess(List<String> jarPath){
        G.reset();
        List<String> argsList = new ArrayList<>();
        String libsAll = Config.RT_JAR;
        argsList.addAll(Arrays.asList(new String[]{
                "-allow-phantom-refs",
                "-w",
                "-keep-line-number", "enabled",
                "-cp", libsAll}));
        for (String s : jarPath) {
            argsList.add("-process-dir");
            argsList.add(s);
        }
        argsList.addAll(Arrays.asList(new String[]{"-p", "jb", "use-original-names:true"}));
        String[] args;
        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);
        Options.v().set_keep_line_number(true);
        Options.v().set_verbose(true);
        Options.v().set_keep_line_number(true);
        Options.v().setPhaseOption("cg", "all-reachable:true");
        Options.v().set_no_bodies_for_excluded(true);
        Options.v().set_app(true);
        List llo = Options.v().classes();
    }
}

