package dataStructure;

import soot.SootClass;
import soot.SootMethod;
import soot.Type;
import soot.tagkit.*;

import java.util.*;

public class scanMethod {
    private scanClass sc;
    private SootMethod sootMethod;
    private List<annotation> methodAnnotations;
    private List<annotation> paramAnnotations;


    public scanMethod(SootMethod sootMethod,scanClass sc){
        this.sc = sc;
        this.sootMethod = sootMethod;
        methodAnnotations = new ArrayList<>();
        paramAnnotations = new ArrayList<>();
    }

    /**
     * 设置方法级别注解
     */
    public void setMethodAnnotations(){
        List<Tag> tags = sootMethod.getTags();
        for(Tag tag : tags){
            if(tag instanceof VisibilityAnnotationTag){
                List<AnnotationTag> methodAnnotationTags = ((VisibilityAnnotationTag) tag).getAnnotations();
                for(AnnotationTag annotationTag : methodAnnotationTags){
                    addMethodAnnotation(annotationTag,"method");
                }
            }
            else if(tag instanceof VisibilityParameterAnnotationTag && !(tag instanceof VisibilityLocalVariableAnnotationTag)){
                List<VisibilityAnnotationTag> paramAnnotationTags = ((VisibilityParameterAnnotationTag) tag).getVisibilityAnnotations();
                for(int i = 0; i < paramAnnotationTags.size(); i++){
                    VisibilityAnnotationTag paramAnnotationTag = paramAnnotationTags.get(i);
                    if(paramAnnotationTag == null) continue;
                    for(AnnotationTag annotationTag : paramAnnotationTag.getAnnotations()){
                        addMethodAnnotation(annotationTag,"param");
                    }
                }
            }
        }


    }

    /**
     * @param annotationTag
     */
    private void addMethodAnnotation(AnnotationTag annotationTag,String location){
        String type = annotationTag.getType();
        Collection<AnnotationElem> elems = annotationTag.getElems();
        if(location.equals("method")){
            methodAnnotations.add(new annotation(type,new ArrayList<>(elems)));
        }
        else if(location.equals("param")){
            paramAnnotations.add(new annotation(type,new ArrayList<>(elems)));
        }
    }

    public List<annotation> getMethodAnnotations(){
        return this.methodAnnotations;
    }

    public List<annotation> getParamAnnotations(){
        return this.paramAnnotations;
    }

    public String getName(){
        return this.sootMethod.getName();
    }

    public String getReturnType(){
        return this.sootMethod.getReturnType().toString();
    }

    public SootMethod getSootMethod(){
        return this.sootMethod;
    }

    public scanClass getScanClass(){
        return this.sc;
    }

    public String getModifier(){
        int modifier = sootMethod.getModifiers();
        String modifierName = "";
        switch (modifier){
            case 1:
                modifierName = "public";
                break;
            case 2:
                modifierName = "private";
                break;
            case 4:
                modifierName = "protected";
        }
        return modifierName;
    }

    public String getReturn(){
        return this.sootMethod.getReturnType().toString();
    }

    public List<SootClass> getThrow(){
        return this.sootMethod.getExceptions();
    }

    /**
     * @return
     */
    public String[] getParameters(){
        List<Type> list = this.sootMethod.getParameterTypes();
        String[] res = new String[list.size()];
        int index = 0;
        for(Type type : list){
            String[] str = type.toString().split("\\.");
            res[index++] = str[str.length - 1];
        }
        return res;
    }

    /**
     * @return
     */
    public String getMethodFullName(){
        //<BOOT-INF.classes.com.example.demo.Person: java.lang.String Person(java.lang.String)>
        String tempName = sootMethod.toString();
        String[] str = tempName.split(" ");
        String methodName = str[str.length - 1];
        String prefix = "BOOT-INF.classes.";
        return sootMethod.getDeclaringClass() + "." + methodName.substring(0,methodName.length() - 1);
    }

    public List<Type> getParamTypes(){
        return this.sootMethod.getParameterTypes();
    }
}
