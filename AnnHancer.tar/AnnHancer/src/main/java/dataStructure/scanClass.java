package dataStructure;

import com.alibaba.fastjson.JSONObject;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationTag;
import soot.tagkit.Tag;
import soot.tagkit.VisibilityAnnotationTag;
import soot.util.Chain;
import soot.util.HashChain;

import java.util.*;

public class scanClass {
    private SootClass sootClass;
    private List<SootMethod> sootMethods;
    private List<scanMethod> scanMethods;
    private List<annotation> classAnnotations;
    private List<scanField> scanFields;
    private String name;
    private String packageName;
    private List<String> interfaceNames;
    private List<String> parents;

    public scanClass(){}

    public scanClass(SootClass sootClass){
        this.sootClass = sootClass;
        this.sootMethods = sootClass.getMethods();
        this.scanMethods = new ArrayList<>();
        this.classAnnotations = new ArrayList<>();
        this.packageName = sootClass.getPackageName();
        this.scanFields = new ArrayList<>();
        this.interfaceNames = new ArrayList<>();
        this.parents = new ArrayList<>();
    }

    /**
     */
    public void setAnnotations(){
//        String remove = "BOOT-INF.classes.";
        name = sootClass.getName();
        List<Tag> tags = sootClass.getTags();
        for(Tag tag : tags){
            if(tag instanceof VisibilityAnnotationTag){
                VisibilityAnnotationTag vaTag = (VisibilityAnnotationTag) tag;
                List<AnnotationTag> annotationTags = vaTag.getAnnotations();
                for (AnnotationTag annotationTag : annotationTags) {
                    addClassAnnotation(annotationTag);
                }
            }
        }
        for(SootMethod sootMethod : sootMethods){
            scanMethod sm = new scanMethod(sootMethod,this);
            sm.setMethodAnnotations();
            scanMethods.add(sm);
        }
        Chain<SootField> fields = sootClass.getFields();
        if(fields != null){
            for(SootField sf : fields){
                scanField field = new scanField(sf,sootClass.getName());
                field.handleScanField();
                scanFields.add(field);
            }
        }
    }

    /**
     */
    public void setInterfaceName(){
        for(SootClass sc : sootClass.getInterfaces()){
            String name = sc.getName();
            this.interfaceNames.add(name);
        }
    }

    /**
     * @param annotationTag
     */
    private void addClassAnnotation(AnnotationTag annotationTag){
        String type = annotationTag.getType();
        Collection<AnnotationElem> elems = annotationTag.getElems();
        classAnnotations.add(new annotation(type,new ArrayList<>(elems)));
    }

    public List<scanMethod> getScanMethods(){
        return this.scanMethods;
    }

    public List<annotation> getClassAnnotations(){
        return this.classAnnotations;
    }

    public String getName(){
        return this.name;
    }

    public Chain<SootClass> getInterfaces(){
        return sootClass.getInterfaces();
    }

    public boolean hasSuperClass(){
        return sootClass.hasSuperclass();
    }

    public SootClass getSuperClass(){
        return sootClass.getSuperclass();
    }

    public List<scanField> getScanFields(){
        return this.scanFields;
    }

    public String getPackageName(){
        return this.packageName;
    }

    public Map<String,Integer> classifyAnnotations(){
        Map<String,Integer> map = new HashMap<>();
        //classAnnotations
        for(annotation a : classAnnotations){
            map.put(a.getName(),map.getOrDefault(a.getName(),0) + 1);
        }
        //methodAnnotations
        for(scanMethod sm : scanMethods){
            for(annotation a : sm.getMethodAnnotations()){
                map.put(a.getName(),map.getOrDefault(a.getName(),0) + 1);
            }
        }
        //fieldAnnotations
        for(scanField field : scanFields){
            for(annotation a : field.getFieldAnnotations()){
                map.put(a.getName(),map.getOrDefault(a.getName(),0) + 1);
            }
        }
        return map;
    }

    public boolean isInterface(){
        return sootClass.isInterface();
    }

    public List<String> getInterfaceNames(){
        return this.interfaceNames;
    }

    public void setParents(List<String> parents){
        this.parents.addAll(parents);
    }

    /**
     * @return
     */
    public List<String> getParents(){
        return this.parents;
    }
}
