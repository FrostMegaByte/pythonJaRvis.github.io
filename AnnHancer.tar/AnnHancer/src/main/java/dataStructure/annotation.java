package dataStructure;

import soot.tagkit.AnnotationElem;

import java.util.List;
import java.util.Map;

public class annotation {
    private String name;
    private List<AnnotationElem> params;

    public annotation(String name,List<AnnotationElem> params){
        this.name = name;
        this.params = params;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public List<AnnotationElem> getParams(){
        return this.params;
    }

    public void setParams(List<AnnotationElem> params){
        this.params = params;
    }
}
