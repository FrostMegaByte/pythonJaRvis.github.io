package dataStructure;

import soot.SootField;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationTag;
import soot.tagkit.Tag;
import soot.tagkit.VisibilityAnnotationTag;

import java.util.ArrayList;
import java.util.List;

public class scanField {
    private String fieldName;
    private String fieldType;
    private String originalType;
    private String className;

    private List<annotation> fieldAnnotations;
    private SootField sootField;

    public scanField(SootField sf,String className){
        sootField = sf;
        fieldAnnotations = new ArrayList<>();
        this.className = className;
    }

    public void handleScanField(){
        this.fieldName = sootField.getName();
        this.fieldType = sootField.getType().toString();
        this.originalType = sootField.getType().toString();
        List<Tag> tags = sootField.getTags();
        for(Tag tag : tags){
            if(tag instanceof VisibilityAnnotationTag){
                List<AnnotationTag> annotationTags = ((VisibilityAnnotationTag) tag).getAnnotations();
                for(AnnotationTag annotationTag : annotationTags){
                    annotation a = new annotation(annotationTag.getType(),new ArrayList<>(annotationTag.getElems()));
                    this.fieldAnnotations.add(a);
                }
            }
        }
    }

    public String getFieldName(){
        return this.fieldName;
    }

    public void setFieldType(String type){
        this.fieldType = type;
    }

    public String getFieldType(){
        return this.fieldType;
    }

    public List<annotation> getFieldAnnotations(){
        return this.fieldAnnotations;
    }

    public String getClassName(){
        return this.className;
    }

    public String getOriginalType(){
        return sootField.getType().toString();
    }

    public boolean getModified(){
        return !originalType.equals(fieldType);
    }
}
