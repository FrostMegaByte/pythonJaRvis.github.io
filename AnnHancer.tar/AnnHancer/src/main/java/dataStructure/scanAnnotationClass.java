package dataStructure;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import soot.SootClass;
import soot.tagkit.AnnotationTag;
import soot.tagkit.Tag;
import soot.tagkit.VisibilityAnnotationTag;

import java.util.ArrayList;
import java.util.List;

public class scanAnnotationClass{
    private boolean isInherited;
    private SootClass sootClass;
    private String annotationName;

    public scanAnnotationClass(SootClass sootClass){
        this.sootClass = sootClass;
    }

    public void setAnnotationInfo(JSONObject object){
        List<String> annotations = new ArrayList<>();
        for(String moduleName : object.keySet()){
            JSONArray arr = object.getJSONArray(moduleName);
            for(Object tmp : arr){
                String annotationName = (String) tmp;
                annotations.add(annotationName);
            }
        }

        List<Tag> tags = sootClass.getTags();
        for(Tag tag : tags){
            if(tag instanceof VisibilityAnnotationTag){
                List<AnnotationTag> annotationTags = ((VisibilityAnnotationTag) tag).getAnnotations();
                for(AnnotationTag annotationTag : annotationTags){
                    String type = annotationTag.getType();
                    if(annotations.contains(type)){
                        this.annotationName = type;
                    }
                }
            }
        }
        System.out.println();
    }

    public String getAnnotationName(){
        return this.annotationName;
    }

    public String getAnnotationType(){
        return this.sootClass.getName();
    }

}


