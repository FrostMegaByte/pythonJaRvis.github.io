package base.util;


import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import java.io.IOException;

public class PropertyUtil {

    public static String read(String path,String key) throws IOException {
        Properties props = new Properties();
        props.load(new FileInputStream(path));
        return props.getProperty(key);
    }

    public static void main(String[] args) throws Exception{
        String name = read("D:/git/demo/src/main/resources/application.properties","server.port");
        System.out.println(name);
    }
}
