package base.util;

import edu.fdu.se.callgraph.impurity.bean.AbstractNode;
import edu.fdu.se.callgraph.impurity.bean.Node;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class CountUtil {
    public static int getCount(List<Node> roots){
        List<String> allNodeNames = new ArrayList<>();
        for(Node root : roots){
            allNodeNames.add(root.toString());
            Queue<Node> queue = new LinkedList<>();
            queue.add(root);
            while(!queue.isEmpty()){
                Node cur = queue.poll();
                if(cur.getChildren() == null || cur.getChildren().size() == 0){
                    continue;
                }
                for(AbstractNode child : cur.getChildren()){
                    String nodeName = child.toString();
                    if(allNodeNames.contains(nodeName)){
                        continue;
                    }
                    allNodeNames.add(nodeName);
                    queue.add((Node)child);
                }
            }
        }
        return allNodeNames.size();
    }
}
