package base.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.io.*;

public class JsonUtil {
    /**
     * @param filePath
     * @return
     */
    public static String readJsonFile(String filePath){
        BufferedReader reader = null;
        String readJson = "";
        try {
            FileInputStream fileInputStream = new FileInputStream(filePath);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream,"UTF-8");
            reader = new BufferedReader(inputStreamReader);
            String tempString = null;
            while ((tempString = reader.readLine()) != null){
                readJson += tempString;
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (reader != null){
                try {
                    reader.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        return readJson;
    }

    /**
     * @param filePath
     * @return
     */
    public static JSONObject readJsonObject(String filePath){
        String json = readJsonFile(filePath);
        JSONObject jsonObject = JSON.parseObject(json);
        return jsonObject;
    }

    /**
     * @param filePath
     * @return
     */
    public static JSONArray readJsonArray(String filePath){
        String json = readJsonFile(filePath);
        JSONArray jsonArray = JSON.parseArray(json);
        return jsonArray;
    }

    /**
     * @param savePath
     * @param obj
     * @param isFormatted
     */
    public static void writeJson(String savePath, Object obj, boolean isFormatted) {
        try {
            File file = new File(savePath);
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter f = new FileWriter(savePath);
            if(isFormatted)
                f.write(JSON.toJSONString(obj, SerializerFeature.PrettyFormat,SerializerFeature.WriteMapNullValue));// 格式化写入
            else
                f.write(obj.toString());
            f.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


