package base.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class Config {
    public static String RT_JAR;
    public static String LOG_PATH;
    public static String JAVA_DOC_PATH;
    public static String CLASSIFICATION_PATH;

    public static String PROJECT_NAME;
    public static List<String> JAR_PATH;
    public static String OUTPUT_PATH;
    public static String PROPERTY_PATH;
    public static List<String> SPRING_JAR_PATH;

    public static void setProperty(String path) throws Exception{
        Properties properties = new Properties();
        BufferedReader reader = new BufferedReader(new FileReader(path));
        properties.load(reader);

        RT_JAR = properties.getProperty("RT_JAR");
        LOG_PATH = properties.getProperty("LOG_PATH");
        JAVA_DOC_PATH = properties.getProperty("JAVA_DOC_PATH");
        CLASSIFICATION_PATH = properties.getProperty("CLASSIFICATION_PATH");
    }

    public static void set(String projectPath, String outputPath, String propertyPATH){
        JAR_PATH = new ArrayList<>();
        getJarPath(projectPath,JAR_PATH);
        SPRING_JAR_PATH = new ArrayList<>();
        getJarPath(outputPath,SPRING_JAR_PATH);
        OUTPUT_PATH = outputPath;
        PROJECT_NAME = getProjectName(projectPath);
        PROPERTY_PATH = propertyPATH;
    }

    public static String getProjectName(String projectPath){
        String[] str = projectPath.split(File.separator);
        String jarName = str[str.length - 1];
        return jarName;
    }

    private static void getJarPath(String projectPath,List<String> list){
        File dir = new File(projectPath);
        File[] files = dir.listFiles();
        for(File file : files){
            if(file.isDirectory()){
                getJarPath(file.getAbsolutePath(),list);
            }
            if(file.getAbsolutePath().endsWith(".jar")){
                list.add(file.getAbsolutePath());
            }
        }
    }
}
