package Cache;

import com.alibaba.fastjson.JSONArray;
import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.AbstractNode;
import edu.fdu.se.callgraph.impurity.bean.Node;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class cacheScanner {
    private List<scanClass> classes;

    private List<String> cacheAnnotations = new ArrayList<>();

    private List<Node> res = new ArrayList<>();
    private double time;

    public cacheScanner(List<scanClass> classes){
        this.classes = classes;
    }

    public double getTime(){
        return this.time;
    }

    public void scan(CallGraphMain callGraphMain,List<String> jarList){
        for(scanClass sc : classes){
            for(scanMethod sm : sc.getScanMethods()){
                for(annotation a : sm.getMethodAnnotations()){
                    if(a.getName().equals("Lorg/springframework/cache/annotation/Cacheable;")
                            || a.getName().equals("Lorg/springframework/cache/annotation/CacheEvict;")
                            || a.getName().equals("Lorg/springframework/cache/annotation/CachePut;")
                            || a.getName().equals("Lorg/springframework/cache/annotation/Caching;")){
                        cacheAnnotations.add(a.getName());
                    }
                }
            }
        }
        post(callGraphMain,jarList);
    }

    private void post(CallGraphMain callGraphMain,List<String> jarList){
        long start = System.currentTimeMillis();
        JSONArray arr = new JSONArray();
        arr.add("org.springframework.cache.interceptor.CacheAspectSupport.execute(org.springframework.cache.interceptor.CacheOperationInvoker,java.lang.reflect.Method,org.springframework.cache.interceptor.CacheAspectSupport$CacheOperationContexts)");
        CallGraphBean callGraphBean = callGraphMain.generateCallGraph(arr,jarList);
        List<Node> roots = callGraphBean.getCiaMethod();
        long end = System.currentTimeMillis();
        this.time += (double)(end - start) / 60000;
        List<String> names = new ArrayList<>();
        for(Node root : roots){
            for(AbstractNode child : root.getChildren()){
                String name = child.toString();
                //CacheEvict
                if(name.contains("processCacheEvicts")){
                    for(String annotationName : cacheAnnotations){
                        if(annotationName.contains("CacheEvict")){
                            if(!names.contains(child.toString())){
                                res.add((Node)child);
                                names.add(child.toString());
                            }
                        }
                    }
                }
                //Cacheable
                else if(name.contains("findCachedItem")){
                    for(String annotationName : cacheAnnotations){
                        if(annotationName.contains("Cacheable")){
                            if(!names.contains(child.toString())){
                                res.add((Node)child);
                                names.add(child.toString());
                            }
                        }
                    }
                } else if(name.contains("collectPutRequests")){
                    for(String annotationName : cacheAnnotations){
                        if(annotationName.contains("CachePut")){
                            if(!names.contains(child.toString())){
                                res.add((Node)child);
                                names.add(child.toString());
                            }
                        }
                    }
                } else if(name.contains("apply")){
                    for(String annotationName : cacheAnnotations){
                        if(annotationName.contains("CachePut")){
                            if(!names.contains(child.toString())){
                                res.add((Node)child);
                                names.add(child.toString());
                            }
                        }
                    }
                }
                else{
                    if(!names.contains(child.toString())){
                        res.add((Node)child);
                        names.add(child.toString());
                    }
                }
            }
        }
    }

    public List<Node> getAllNodes(){
        return this.res;
    }

}
