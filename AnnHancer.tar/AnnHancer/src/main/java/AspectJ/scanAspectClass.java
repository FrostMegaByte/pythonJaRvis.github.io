package AspectJ;

import IOC.bean.Bean;
import base.util.JsonUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import dataStructure.annotation;
import dataStructure.scanAnnotationClass;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.impurity.bean.Node;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationStringElem;

import java.util.*;

public class scanAspectClass {
    private List<scanClass> scanClasses;
    private List<JoinPoint> joinPoints = new ArrayList<>();
    private Map<String,JoinPoint> joinPointMap = new HashMap<>();
    private List<Bean> allBeans;
    private List<scanAnnotationClass> scanAnnotationClasses;
    Map<scanMethod,List<scanMethod>> res = new HashMap<>();


    public scanAspectClass(List<scanClass> scanClasses,List<Bean> allBeans,List<scanAnnotationClass> scanAnnotationClasses){
        this.scanClasses = scanClasses;
        this.allBeans = allBeans;
        this.scanAnnotationClasses = scanAnnotationClasses;
    }


    public Map<scanMethod,List<scanMethod>> scan(String path){
        for(scanClass sc : scanClasses){
            List<annotation> classAnnotations = sc.getClassAnnotations();
            for(annotation an : classAnnotations){
                if(an.getName().equals("Lorg/aspectj/lang/annotation/Aspect;")){
                    handleAspectClass(sc);
                    for(scanMethod sm : sc.getScanMethods()) {
                        List<annotation> annotations = sm.getMethodAnnotations();
                        for (annotation a : annotations) {
                            if (a.getName().equals("Lorg/aspectj/lang/annotation/Before;")) {
                                for (AnnotationElem elem : a.getParams()) {
                                    String pattern = ((AnnotationStringElem) elem).getValue();
                                    for (JoinPoint joinPoint : joinPoints) {
                                        if (joinPoint.getName().equals(pattern)) {
                                            joinPoint.setBeforeMethod(sm);
                                        }
                                    }
                                }
                            } else if (a.getName().equals("Lorg/aspectj/lang/annotation/After;")) {
                                for (AnnotationElem elem : a.getParams()) {
                                    String pattern = ((AnnotationStringElem) elem).getValue();
                                    for (JoinPoint joinPoint : joinPoints) {
                                        if (joinPoint.getName().equals(pattern)) {
                                            joinPoint.setAfterMethod(sm);
                                        }
                                    }
                                }
                            } else if (a.getName().equals("Lorg/aspectj/lang/annotation/AfterReturning;")) {
                                for (AnnotationElem elem : a.getParams()) {
                                    String pattern = ((AnnotationStringElem) elem).getValue();
                                    for (JoinPoint joinPoint : joinPoints) {
                                        if (joinPoint.getName().equals(pattern)) {
                                            joinPoint.setAfterReturnMethod(sm);
                                        }
                                    }
                                }
                            } else if (a.getName().equals("Lorg/aspectj/lang/annotation/AfterThrowing;")) {
                                for (AnnotationElem elem : a.getParams()) {
                                    String pattern = ((AnnotationStringElem) elem).getValue();
                                    for (JoinPoint joinPoint : joinPoints) {
                                        if (joinPoint.getName().equals(pattern)) {
                                            joinPoint.setAfterThrowingMethod(sm);
                                        }
                                    }
                                }
                            } else if (a.getName().equals("Lorg/aspectj/lang/annotation/Around;")) {
                                for (AnnotationElem elem : a.getParams()) {
                                    String pattern = ((AnnotationStringElem) elem).getValue();
                                    for (JoinPoint joinPoint : joinPoints) {
                                        if (joinPoint.getName().equals(pattern)) {
                                            joinPoint.setAroundMethod(sm);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //writeIntoJson(path);
        return handleJoinPointCallGraph();
    }

    /**
     */
    private Map<scanMethod,List<scanMethod>> handleJoinPointCallGraph(){
        for(JoinPoint point : joinPoints){
            //切点函数
            List<scanMethod> methods = point.getMethods();
            for(scanMethod method : methods){
                res.put(method,new ArrayList<>());
                //前置函数
                scanMethod before = point.getBeforeMethod();
                if(before != null){
                    res.get(method).add(before);
                }
                //后置函数
                List<scanMethod> afterMethods = new ArrayList<>();
                afterMethods.add(point.getAfterMethod());
                afterMethods.add(point.getAfterReturnMethod());
                afterMethods.add(point.getAfterThrowingMethod());
                for(scanMethod sm : afterMethods){
                    if(sm == null){
                        continue;
                    }
                    res.get(method).add(sm);
                }
                res.get(method).add(point.getAroundMethod());
            }

        }
        return res;
    }

    /**
     * @param path
     */
    public void writeIntoJson(String path){
        JSONObject res = new JSONObject();
        res.put("JoinPointSum",joinPoints.size());
        JSONArray joinPointArray = new JSONArray();
        for(JoinPoint joinPoint : joinPoints){
            JSONObject object = new JSONObject();
            object.put("ClassName",joinPoint.getClassName());
            if(joinPoint.getBeforeMethod() != null){
                object.put("BeforeMethod",joinPoint.getBeforeMethod().getSootMethod().getName());
            }
            object.put("PointCutSum",joinPoint.getMethods().size());
            JSONArray pointCuts = new JSONArray();
            for(scanMethod sm : joinPoint.getMethods()){
                pointCuts.add(sm.getName());
            }
            object.put("PointCuts",pointCuts);
            if(joinPoint.getAfterMethod() != null){
                object.put("AfterMethod",joinPoint.getAfterMethod().getSootMethod().getName());
            }
            if(joinPoint.getAfterThrowingMethod() != null){
                object.put("AfterThrowingMethod",joinPoint.getAfterThrowingMethod().getSootMethod().getName());
            }
            if(joinPoint.getAfterReturnMethod() != null){
                object.put("AfterReturningMethod",joinPoint.getAfterReturnMethod().getSootMethod().getName());
            }
            joinPointArray.add(object);
        }
        res.put("JoinPoints",joinPointArray);
        JsonUtil.writeJson(path,res,true);
    }

    /**
     * @param sc
     */
    private void handleAspectClass(scanClass sc){
        List<scanMethod> classMethods = sc.getScanMethods();
        for(scanMethod sm : classMethods){
            for(annotation a : sm.getMethodAnnotations()){
                if(a.getName().equals("Lorg/aspectj/lang/annotation/Pointcut;")){
                    JoinPoint joinPoint = new JoinPoint(sm.getName() + "()",sc.getName());
                    for(AnnotationElem elem : a.getParams()){
                        String pattern = ((AnnotationStringElem) elem).getValue();
                        joinPoint.setMethods(PointCutMatcher.handleComposedPattern(scanClasses,pattern,allBeans,scanAnnotationClasses));
                    }
                    joinPoints.add(joinPoint);
                    joinPointMap.put(joinPoint.getName(),joinPoint);
                }
            }
        }
    }
}
