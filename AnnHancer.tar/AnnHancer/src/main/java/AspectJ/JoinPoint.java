package AspectJ;


import dataStructure.scanMethod;

import java.util.List;

public class JoinPoint {
    private String name;
    private String className;

    private List<scanMethod> methods;

    private scanMethod BeforeMethod;

    private scanMethod AfterMethod;

    private scanMethod AfterReturnMethod;

    private scanMethod AfterThrowingMethod;

    private scanMethod AroundMethod;

    public JoinPoint(String name,String className){
        this.name = name;
        this.className = className;
    }

    public void setMethods(List<scanMethod> methods){
        this.methods = methods;
    }

    public String getName(){
        return this.name;
    }

    public void setBeforeMethod(scanMethod method){
        this.BeforeMethod = method;
    }

    public void setAfterMethod(scanMethod method){
        this.AfterMethod = method;
    }

    public void setAfterReturnMethod(scanMethod method){
        this.AfterReturnMethod = method;
    }

    public void setAfterThrowingMethod(scanMethod method){
        this.AfterThrowingMethod = method;
    }

    public void setAroundMethod(scanMethod method){
        this.AroundMethod = method;
    }

    public scanMethod getBeforeMethod(){
        return this.BeforeMethod;
    }

    public scanMethod getAfterMethod(){
        return this.AfterMethod;
    }

    public scanMethod getAfterReturnMethod(){
        return this.AfterReturnMethod;
    }

    public scanMethod getAfterThrowingMethod(){
        return this.AfterThrowingMethod;
    }

    public scanMethod getAroundMethod(){
        return this.AroundMethod;
    }

    public List<scanMethod> getMethods(){
        return this.methods;
    }

    public String getClassName(){
        return this.className;
    }
}
