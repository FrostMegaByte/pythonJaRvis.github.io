package AspectJ;

import IOC.bean.Bean;
import dataStructure.annotation;
import dataStructure.scanAnnotationClass;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import soot.SootClass;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class PointCutMatcher {

    public static List<scanMethod> handlePattern(List<scanClass> scanClasses,String pattern,List<Bean> allBeans,List<scanAnnotationClass> scanAnnotationClasses){
        if(pattern.startsWith("execution")){
            return handleExecutionExpression(scanClasses,pattern.substring("execution".length() + 1,pattern.length() - 1));
        }
        else if(pattern.startsWith("within")){
            return handleWithinExpression(scanClasses,pattern.substring("within".length() + 1,pattern.length() - 1));
        }
        else if(pattern.startsWith("this")){
            return handleThisExpression(scanClasses,pattern.substring("this".length() + 1,pattern.length() - 1));
        }
        else if(pattern.startsWith("target")){
            return handleTargetExpression(scanClasses,pattern.substring("target".length() + 1,pattern.length() - 1));
        }
        else if(pattern.startsWith("args")){
            return handleArgsExpression(scanClasses,pattern.substring("args".length() + 1,pattern.length() - 1));
        }
        else if(pattern.startsWith("@within")){
            return handleWithinAnnotation(scanClasses,pattern.substring("@within".length() + 1,pattern.length() - 1));
        }
        else if(pattern.startsWith("@target")){
            return handleWithinAnnotation(scanClasses,pattern.substring("@target".length() + 1,pattern.length() - 1));
        }
        else if(pattern.startsWith("@args")){
            return new ArrayList<>();
        }
        else if(pattern.startsWith("@annotation")){
            return handleMethodAnnotation(scanClasses,pattern.substring("@annotation".length() + 1,pattern.length() - 1));
        }
        else if(pattern.startsWith("bean")){
            return handleBeanExpression(allBeans,pattern.substring("bean".length() + 1,pattern.length() - 1));
        }
        return new ArrayList<>();
    }

    /**
     * @param classes
     * @param pattern
     * @return
     */
    public static List<scanMethod> handleComposedPattern(List<scanClass> classes,String pattern,List<Bean> allBeans,List<scanAnnotationClass> scanAnnotationClasses){
        List<scanMethod> res = new ArrayList<>();
        List<scanMethod> removeList = new ArrayList<>();
        if(!pattern.contains("&&") && !pattern.contains("||") && !pattern.contains("!")){
            return handlePattern(classes,pattern,allBeans,scanAnnotationClasses);
        }
        if(pattern.contains("&&")){
            String[] patterns = pattern.split("&&");
            for(String newPattern : patterns){
                if(newPattern.trim().startsWith("!")){
                    removeList.addAll(handlePattern(classes,newPattern.trim().substring(1),allBeans,scanAnnotationClasses));
                    continue;
                }
                if(res.size() == 0){
                    res.addAll(handlePattern(classes,newPattern.trim(),allBeans,scanAnnotationClasses));
                }
                else{
                    List<scanMethod> temp = handlePattern(classes,newPattern.trim(),allBeans,scanAnnotationClasses);
                    res = res.stream().filter(item -> temp.contains(item)).collect(Collectors.toList());
                }
            }
        }
        else if(pattern.contains("||")){
            String[] patterns = pattern.split("\\||");
            for(String newPattern : patterns){
                res.addAll(handlePattern(classes,newPattern.trim(),allBeans,scanAnnotationClasses));
            }
            res = res.stream().distinct().collect(Collectors.toList());
        }
        return res;
    }

    /**
     * @param scanClasses
     * @param expression
     * @return
     */
    public static List<scanMethod> handleExecutionExpression(List<scanClass> scanClasses,String expression){
        List<scanMethod> res = new ArrayList<>();
        String[] args = expression.split(" ");
        String modifier = null,returnType = null,className = null,methodName = null,throwType = null;
        //locate method name
        int index = 0;
        for(int i = 0; i < args.length; i++){
            String arg = args[i];
            if(arg.contains("(") && arg.contains(")")){
                methodName = arg;
                index = i;
            }
        }
        //throw type
        if(index != args.length - 1){
            throwType = args[args.length - 1];
        }
        //modifier
        if(args[0].equals("public") || args[0].equals("protected") || args[0].equals("private")){
            modifier = args[0];
        }
        //ret type
        if(modifier != null){
            returnType = args[1];
        }
        else{
            returnType = args[0];
        }
        //dec type
        if((index == 2 && modifier == null) || index == 3){
            className = args[index - 1];
        }

        int i = methodName.indexOf('(');
        String methodPattern = methodName.substring(0,i);
        String[] str = methodPattern.split("\\.");
        StringBuilder sb = new StringBuilder();
        for(int j = 0; j < str.length - 1; j++){
            sb.append(str[j]).append(".");
        }
        sb.deleteCharAt(sb.length() - 1);
        String argName = methodName.substring(i,methodName.length() - 1);
        List<scanClass> candidates = AspectPathMatcher.classPatternMatcher(scanClasses,sb.toString());
        methodName = str[str.length - 1];

        for(scanClass sc : candidates){
            List<scanMethod> methods = sc.getScanMethods();
            for(scanMethod method : methods){
                if(modifier != null){
                    if(!modifier.equals(method.getModifier())){
                        continue;
                    }
                }
                if(!returnType.equals("*") && !returnType.equals(method.getReturn())){
                    continue;
                }
                if(className != null){
                    if(!className.equals(method.getScanClass().getName())){
                        continue;
                    }
                }
                if(throwType != null){
                    List<SootClass> exceptions = method.getThrow();
                    boolean contains = false;
                    for(SootClass exception : exceptions){
                        if(exception.getName().equals(throwType)){
                            contains = true;
                        }
                    }
                    if(contains) continue;
                }
                if(!isValidParams(argName,method)){
                    continue;
                }
                if(isValidMethodName(methodName,method.getName())){
                    res.add(method);
                }
            }
        }
        return res;
    }

    private static boolean isValidMethodName(String pattern,String name){
        if(pattern.equals("*")){
            return true;
        }
        if(pattern.contains("*")){
            int index = pattern.indexOf('*');
            for(int i = 0; i < index; i++){
                if(name.charAt(i) != pattern.charAt(i)){
                    return false;
                }
            }
            int j = name.length() - 1;
            for(int i = pattern.length() - 1; i > index; i--){
                if(name.charAt(j--) != pattern.charAt(i)){
                    return false;
                }
            }
            return true;
        }
        if(!name.equals(pattern)){
            return false;
        }
        else{
            return true;
        }
    }

    /**
     * @param argName
     * @param method
     * @return
     */
    private static boolean isValidParams(String argName,scanMethod method){
        String[] params = method.getParameters();
        String[] args = argName.split(",");
        if(argName.contains("..")){
            int index = 0;
            for(int i = 0; i < args.length; i++){
                if(args[i].equals("..")){
                    index = i;
                }
            }
            for(int i = 0; i < index; i++){
                if(!params[i].equals(args[i])){
                    return false;
                }
            }
            int j = params.length - 1;
            for(int i = args.length - 1; i > index; i--){
                if(!params[j--].equals(args[i])){
                    return false;
                }
            }
            return true;
        }
        if(params.length != args.length){
            return false;
        }
        for(int i = 0; i < params.length; i++){
            if(!args[i].equals("*") && !args[i].equals(params[i])){
                return false;
            }
        }
        return true;
    }

    /**
     * @param classes
     * @param expression
     * @return
     */
    public static List<scanMethod> handleWithinExpression(List<scanClass> classes,String expression){
        List<scanClass> matchedClasses = AspectPathMatcher.classPatternMatcher(classes,expression);
        List<scanMethod> res = new ArrayList<>();
        for(scanClass matchedClass : matchedClasses){
            res.addAll(matchedClass.getScanMethods());
        }
        return res;
    }

    /**
     * @param classes
     * @param className
     * @return
     */
    public static List<scanMethod> handleThisExpression(List<scanClass> classes,String className){
        List<scanMethod> res = new ArrayList<>();
        for(scanClass sc : classes){
            String name = sc.getName();
            String prefix = "BOOT-INF.classes.";
            if(name.contains(prefix)){
                name = name.substring(prefix.length());
            }
            if(name.equals(className)){
                res.addAll(sc.getScanMethods());
            }
        }
        return res;
    }

    /**
     * @param classes
     * @param className
     * @return
     */
    public static List<scanMethod> handleTargetExpression(List<scanClass> classes,String className){
        List<scanMethod> res = new ArrayList<>();
        for(scanClass sc : classes){
            String name = sc.getName();
            String prefix = "BOOT-INF.classes.";
            if(name.contains(prefix)){
                name = name.substring(prefix.length());
            }
            if(name.equals(className)){
                res.addAll(sc.getScanMethods());
            }
        }
        return res;
    }

    /**
     * @param classes
     * @param args
     * @return
     */
    public static List<scanMethod> handleArgsExpression(List<scanClass> classes,String args){
        List<scanMethod> res = new ArrayList<>();
        for(scanClass sc : classes){
            for(scanMethod sm : sc.getScanMethods()){
                if(isValidParams(args,sm)){
                    res.add(sm);
                }
            }
        }
        return res;
    }

    /**
     * @param classes
     * @param annotationName
     * @return
     */
    public static List<scanMethod> handleWithinAnnotation(List<scanClass> classes,String annotationName){
        List<scanMethod> res = new ArrayList<>();
        for(scanClass sc : classes){
            for(annotation a : sc.getClassAnnotations()){
                if(a.getName().equals(annotationName)){
                    res.addAll(sc.getScanMethods());
                }
            }
        }
        return res;
    }

    /**
     * @param classes
     * @param annotationName
     * @return
     */
    public static List<scanMethod> handleTargetAnnotation(List<scanClass> classes,String annotationName){
        List<scanMethod> res = new ArrayList<>();
        for(scanClass sc : classes){
            for(annotation a : sc.getClassAnnotations()){
                if(a.getName().equals(annotationName)){
                    res.addAll(sc.getScanMethods());
                }
            }
        }
        return res;
    }

    /**
     * @param classes
     * @param annotationName
     * @return
     */
    public static List<scanMethod> handleMethodAnnotation(List<scanClass> classes,String annotationName){
        List<scanMethod> res = new ArrayList<>();
        String[] str = annotationName.split("\\.");
        annotationName = str[str.length - 1];
        for(scanClass sc : classes){
            for(scanMethod sm : sc.getScanMethods()){
                for(annotation a : sm.getMethodAnnotations()){
                    if(a.getName().contains(annotationName)){
                        res.add(sm);
                    }
                }
            }
        }
        return res;
    }

    /**
     * @param allBeans
     * @param expression
     * @return
     */
    public static List<scanMethod> handleBeanExpression(List<Bean> allBeans,String expression){
        List<scanMethod> res = new ArrayList<>();
        for(Bean bean : allBeans){
            if(bean.getBeanName().equals(expression)){
                res.add(bean.getConstructorMethod());
            }
        }
        return res;
    }

    /**
     * @param classes
     * @param annotationClasses
     * @return
     */
    public static List<scanMethod> handleAnnotation(List<scanClass> classes,List<scanAnnotationClass> annotationClasses,String annotationName){
        List<scanMethod> res = new ArrayList<>();
        for(scanClass sc : classes){
            for(annotation a : sc.getClassAnnotations()){
                if(a.getName().equals(annotationName)){
                    res.addAll(sc.getScanMethods());
                }
            }
        }
        return res;
    }
}
