package AspectJ;

import dataStructure.scanClass;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AspectPathMatcher {


    /**
     * @param classes
     * @param pattern
     * @return
     */
    public static List<scanClass> classPatternMatcher(List<scanClass> classes, String pattern){
        List<scanClass>  res = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        for(scanClass sc : classes){
            String name = sc.getName();
            String pre = "BOOT-INF.classes.";
            if(name.contains(pre)){
                name = name.substring(pre.length());
            }
            if(visited.contains(name)){
                res.add(sc);
                visited.add(name);
                continue;
            }
            if(pattern.endsWith("+")){
                if(!doMatch(name,pattern.substring(0,pattern.length() - 1))){
                    continue;
                }
                visited.add(name);
                res.add(sc);
            }
            else{
                if(doMatch(name,pattern)){
                    res.add(sc);
                }
            }
        }
        return res;
    }


    /**
     * example : "java.lang.String"
     * pattern : "java.*.String","java.lang.*","java.*.lang.*","java..*","java..*ing","java.*.lang..*"
     *
     * @param name
     * @param pattern
     * @return
     */
    public static boolean doMatch(String name,String pattern){
        int nameIndex = 0;

        int patternIndex = 0;
        int patternLeft = 0;
        while(patternIndex < pattern.length() && nameIndex < name.length()){
            while(patternIndex < pattern.length() && pattern.charAt(patternIndex) != '.'
                    && pattern.charAt(patternIndex) != '*'){
                patternIndex++;
            }
            if(patternIndex - patternLeft >= 1){
                String s = pattern.substring(patternLeft,patternIndex);
                String compare = name.substring(nameIndex,nameIndex + s.length());
                if(!s.equals(compare)){
                    break;
                }
                nameIndex += s.length();
                patternLeft = patternIndex;
            }
            while(patternIndex < pattern.length() && pattern.charAt(patternIndex) == '.'){
                patternIndex++;
            }
            if(patternIndex - patternLeft == 1){
                if(name.charAt(nameIndex) == '.'){
                    patternLeft++;
                    nameIndex++;
                    continue;
                }
            }
            else if(patternIndex - patternLeft > 1){
                if(pattern.charAt(patternIndex) == '*' && patternIndex == pattern.length() - 1){
                    return true;
                }
                else if(pattern.charAt(patternIndex) == '*' && patternIndex != pattern.length() - 1){
                    String end = pattern.substring(++patternIndex);
                    if(name.endsWith(end)){
                        return true;
                    }
                    else{
                        return false;
                    }
                }
            }
            if(patternIndex < pattern.length() && pattern.charAt(patternIndex) == '*'){
                while(patternIndex < pattern.length() && pattern.charAt(patternIndex) != '.'){
                    patternIndex++;
                }
                String tempPattern = pattern.substring(patternLeft,patternIndex);
                patternLeft = patternIndex;
                int nameLeft = nameIndex;
                while(nameIndex < name.length() && name.charAt(nameIndex) != '.'){
                    nameIndex++;
                }
                String tempName = name.substring(nameLeft,nameIndex);
                if(!tempName.endsWith(tempPattern.substring(1))){
                    return false;
                }
            }
        }
        if(nameIndex != name.length()){
            return false;
        }
        return true;
    }
}
