package Validator;

import com.alibaba.fastjson.JSONArray;
import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanField;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.AbstractNode;
import edu.fdu.se.callgraph.impurity.bean.Node;
import soot.Type;
import soot.tagkit.AnnotationTag;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class validScanner {
    private List<scanClass> classes;

    private Map<scanMethod,List<String>> validMethodMap = new HashMap<>();

    private Map<scanMethod,List<AbstractNode>> res = new HashMap<>();

    public validScanner(List<scanClass> classes){
        this.classes = classes;
    }

    private double time = 0;

    public double getTime(){
        return this.time;
    }

    /**
     * @param callGraphMain
     * @param jarList
     */
    private void post(CallGraphMain callGraphMain, List<String> jarList){
        List<AbstractNode> validChildren = new ArrayList<>();
        List<AbstractNode> otherChildren = new ArrayList<>();
        long start = System.currentTimeMillis();
        JSONArray methods = new JSONArray();
        methods.add("org.hibernate.validator.internal.engine.constraintvalidation.ConstraintTree.validateSingleConstraint(org.hibernate.validator.internal.engine.valuecontext.ValueContext,org.hibernate.validator.internal.engine.constraintvalidation.ConstraintValidatorContextImpl,javax.validation.ConstraintValidator)");
        CallGraphBean callGraphBean = callGraphMain.generateCallGraph(methods,jarList);
        long end = System.currentTimeMillis();
        this.time += (double)(end - start) / 60000;
        for(Node root : callGraphBean.getCiaMethod()){
            List<AbstractNode> children = root.getChildren();
            for(AbstractNode child : children){
                String methodName = ((Node) child).getMethodSignatureShortName();
                if(methodName.endsWith("isValid")){
                    validChildren.add(child);
                } else{
                    otherChildren.add(child);
                }
            }
        }

        for(scanMethod sm : validMethodMap.keySet()){
            res.put(sm,new ArrayList<>());
            List<String> validNodes = validMethodMap.get(sm);
            for(AbstractNode child : validChildren){
                String methodName = ((Node) child).getMethodSignatureShortName();
                String className = methodName.split("\\.")[0];
                boolean contains = false;
                for(String annotationName : validNodes){
                    if(className.contains(annotationName)){
                        contains = true;
                    }
                }
                if(!contains){
                    res.get(sm).add(child);
                }
            }
        }

        System.out.println("test");
    }

    /**
     *
     */
    public void scan(CallGraphMain callGraphMain,List<String> jarList){
        Map<scanMethod,List<Type>> methodParamMap = new HashMap<>();
        for(scanClass sc : classes){
            for(scanMethod method : sc.getScanMethods()){
                methodParamMap.put(method,new ArrayList<>());
                for(annotation a : method.getParamAnnotations()){
                    if(a.getName().equals("Ljavax/validation/Valid;") || a.getName().equals("Lorg/springframework/validation/annotation/Validated;")){
                        methodParamMap.get(method).addAll(method.getParamTypes());
                    }
                }
            }
        }
        for(scanClass sc : classes){
            for(scanMethod sm : methodParamMap.keySet()){
                for(Type type : methodParamMap.get(sm)){
                    if(sc.getName().endsWith(type.toString())){
                        if(!validMethodMap.containsKey(sm)){
                            validMethodMap.put(sm,new ArrayList<>());
                        }
                        validMethodMap.get(sm).addAll(getFieldValidAnnotations(sc));
                    }
                }
            }
        }
        post(callGraphMain,jarList);
    }

    /**
     *
     * @param sc
     * @return
     */
    private List<String> getFieldValidAnnotations(scanClass sc){
        List<String> res = new ArrayList<>();
        for(scanField field : sc.getScanFields()){
            for(annotation a : field.getFieldAnnotations()){
                String name = a.getName();
                if(name.startsWith("Ljavax/validation/constraints/")){
                    String[] str = name.split("/");
                    String annotationName = str[str.length - 1];
                    res.add(annotationName.substring(0,annotationName.length() - 1));
                }
            }
        }
        return res;
    }

    public List<Node> getValidNodes(){
        List<Node> nodes = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for(scanMethod sm : res.keySet()){
            for(AbstractNode child : res.get(sm)){
                if(!names.contains(child.toString())){
                    nodes.add((Node) child);
                    names.add(child.toString());
                }
            }
        }
        return nodes;
    }
}
