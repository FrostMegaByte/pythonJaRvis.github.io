package ConditionOn;

import com.alibaba.fastjson.JSONArray;
import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.AbstractNode;
import edu.fdu.se.callgraph.impurity.bean.Node;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConditionOnScanner {
    private List<scanClass> classes;

    private Map<scanClass,List<String>> conditionClassMap = new HashMap<>();
    private Map<scanMethod,List<String>> conditionMethodMap = new HashMap<>();

    private Map<scanClass,List<AbstractNode>> classRes = new HashMap<>();
    private Map<scanMethod,List<AbstractNode>> methodRes = new HashMap<>();
    private double time = 0;

    public ConditionOnScanner(List<scanClass> classes){
        this.classes = classes;
    }

    /**
     */
    public void scan(CallGraphMain callGraphMain, List<String> jarList){
        for(scanClass sc : classes){
            for(annotation a : sc.getClassAnnotations()){
                String className = handleClassName(a.getName());
                if(className.contains("org/springframework/boot/autoconfigure/condition")){
                    if(!conditionClassMap.containsKey(sc)){
                        conditionClassMap.put(sc,new ArrayList<>());
                    }
                    conditionClassMap.get(sc).add(className);
                }
            }
            for(scanMethod sm : sc.getScanMethods()){
                for(annotation a : sm.getMethodAnnotations()){
                    String className = handleClassName(a.getName());
                    if(className.contains("org/springframework/boot/autoconfigure/condition")){
                        if(!conditionMethodMap.containsKey(sm)){
                            conditionMethodMap.put(sm,new ArrayList<>());
                        }
                        conditionMethodMap.get(sm).add(className);
                    }
                }
            }
        }

        post(callGraphMain,jarList);
    }

    /**
     * @param callGraphMain
     * @param jarList
     */
    private void post(CallGraphMain callGraphMain, List<String> jarList){
        List<AbstractNode> conditionChildren = new ArrayList<>();
        List<AbstractNode> otherChildren = new ArrayList<>();

        long start = System.currentTimeMillis();
        JSONArray methods = new JSONArray();
        methods.add("org.springframework.boot.autoconfigure.condition.SpringBootCondition.matches(org.springframework.context.annotation.ConditionContext,org.springframework.core.type.AnnotatedTypeMetadata)");
        CallGraphBean callGraphBean = callGraphMain.generateCallGraph(methods,jarList);
        long end = System.currentTimeMillis();
        this.time += (double)(end - start) / 60000;
        for(Node root : callGraphBean.getCiaMethod()){
            List<AbstractNode> children = root.getChildren();
            for(AbstractNode child : children){
                String methodName = ((Node) child).getMethodSignatureShortName();
                if(methodName.endsWith("getMatchOutcome")){
                    conditionChildren.add(child);
                } else{
                    otherChildren.add(child);
                }
            }
        }

        for(scanClass sc : conditionClassMap.keySet()){
            classRes.put(sc,new ArrayList<>());
            List<String> conditionNodes = conditionClassMap.get(sc);
            for(AbstractNode child : conditionChildren){
                String methodName = ((Node) child).getMethodSignatureShortName();
                String className = methodName.split("\\.")[0];
                boolean contains = false;
                for(String annotationName : conditionNodes){
                    String[] str = annotationName.split("/");
                    String name = getClassNameForCondition(str[str.length - 1]);
                    if(className.contains(name)){
                        contains = true;
                    }
                }
                if(!contains){
                    classRes.get(sc).add(child);
                }
            }
        }

        for(scanMethod sm : conditionMethodMap.keySet()){
            methodRes.put(sm,new ArrayList<>());
            methodRes.get(sm).addAll(otherChildren);
            List<String> conditionNodes = conditionMethodMap.get(sm);
            for(AbstractNode child : conditionChildren){
                String methodName = ((Node) child).getMethodSignatureShortName();
                String className = methodName.split("\\.")[0];
                boolean contains = false;
                for(String annotationName : conditionNodes){
                    String[] str = annotationName.split("/");
                    if(className.contains(getClassNameForCondition(str[str.length - 1]))){
                        contains = true;
                    }
                }
                if(!contains){
                    methodRes.get(sm).add(child);
                }
            }
        }

        System.out.println("test");
    }

    /**
     * @param className
     * @return
     */
    private String handleClassName(String className){
        return className.substring(1,className.length() - 1);
    }

    /**
     * ConditionalOnBean-OnBeanCondition
     * @param className
     * @return
     */
    private String getClassNameForCondition(String className){
        String prefix = "";
        if(className.contains("ConditionalOnMissing")){
            prefix = "ConditionalOnMissing";
        } else{
            prefix = "ConditionalOn";
        }
        return "On" + className.substring(prefix.length()) + "Condition";
    }

    public List<Node> getConditionNodes(){
        List<Node> res = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for(scanClass sc : classRes.keySet()){
            for(AbstractNode child : classRes.get(sc)){
                if(!names.contains(child.toString())){
                    res.add((Node)child);
                    names.add(child.toString());
                }
            }
        }
        for(scanMethod sm : methodRes.keySet()){
            for(AbstractNode child : methodRes.get(sm)){
                if(!names.contains(child.toString())){
                    res.add((Node)child);
                    names.add(child.toString());
                }
            }
        }
        return res;
    }

    public double getTime(){
        return this.time;
    }
}
