package Main;

import AspectJ.scanAspectClass;
import Authorization.authScanner;
import Cache.cacheScanner;
import ConditionOn.ConditionOnScanner;
import IOC.bean.Bean;
import IOC.bean.BeanScanner;
import IOC.scan.componentScanHandler;
import MVC.controllerScanner;
import Validator.validScanner;
import base.config.Config;
import base.util.JsonUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import dataStructure.scanAnnotationClass;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.impurity.bean.Node;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Module implements IModule{
    /**
     * @param classes
     */
    @Override
    public void writeIntoJson(List<scanClass> classes){
        JSONObject object = JsonUtil.readJsonObject(Config.CLASSIFICATION_PATH);

        Map<String,Map<String,Integer>> map = new HashMap<>();
        Map<String,Map<String,List<String>>> location = new HashMap<>();
        Map<String,Integer> unusedMap = new HashMap<>();
        for(scanClass sc : classes){
            Map<String,Integer> classMap = sc.classifyAnnotations();
            for(String annotationName : classMap.keySet()){
                boolean used = false;
                for(String moduleName : object.keySet()){
                    JSONArray arr = object.getJSONArray(moduleName);
                    for(Object tmp : arr){
                        String s = (String)tmp;
                        if(annotationName.startsWith(s)){
                            used = true;
                            if(!map.containsKey(moduleName)){
                                map.put(moduleName,new HashMap<>());
                            }
                            if(!location.containsKey(moduleName)){
                                location.put(moduleName,new HashMap<>());
                            }
                            if(!location.get(moduleName).containsKey(annotationName)){
                                location.get(moduleName).put(annotationName,new ArrayList<>());
                            }
                            location.get(moduleName).get(annotationName).add(sc.getName());
                            map.get(moduleName).put(annotationName,map.get(moduleName).getOrDefault(annotationName,0) + classMap.get(annotationName));
                        }
                    }
                }
                if(!used){
                    unusedMap.put(annotationName,unusedMap.getOrDefault(annotationName,0) + classMap.get(annotationName));
                }
            }
        }
        JSONObject ans = JSON.parseObject(JSON.toJSONString(location));
        JsonUtil.writeJson(Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + "_Location.json",ans,true);

        JSONObject unused = new JSONObject();
        int sum = 0;
        for(String annotationName : unusedMap.keySet()){
            sum += unusedMap.get(annotationName);
            unused.put(annotationName,unusedMap.get(annotationName));
        }
        unused.put("sum",sum);
        JsonUtil.writeJson(Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + "_Unused.json",unused,true);

        JSONObject res = new JSONObject();
        sum = 0;
        for(String moduleName : map.keySet()){
            int count = 0;
            JSONObject tmp = new JSONObject();
            for(String annotation : map.get(moduleName).keySet()){
                int num = map.get(moduleName).get(annotation);
                tmp.put(annotation,num);
                sum += num;
                count += num;
            }
            tmp.put("count",count);
            res.put(moduleName,tmp);
        }
        res.put("sum",sum);
        String path = Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + "_Classification.json";
        JsonUtil.writeJson(path,res,true);
    }

    /**
     *
     * @param classes
     */
    @Override
    public BeanScanner IOC(List<scanClass> classes,Map<String,List<String>> annotationMap) throws Exception{
        componentScanHandler cpsh = new componentScanHandler(classes,annotationMap);
        cpsh.handleComponentScanAnnotations();
        List<scanClass> beans = cpsh.getScannedClasses();
        BeanScanner scanner = new BeanScanner(beans,classes,annotationMap);
        scanner.BeanScannerHandler(Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + "_IOC.json");
        //scanner.writeIntoJson(Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + ".json");
        return scanner;
    }

    /**
     * @param callGraphMain
     * @param classes
     */
    @Override
    public controllerScanner MVC(CallGraphMain callGraphMain, List<scanClass> classes){
        controllerScanner cs = new controllerScanner(classes);
        cs.scan(callGraphMain,Config.JAR_PATH);
        return cs;
    }

    @Override
    public scanAspectClass AOP(CallGraphMain callGraphMain,List<scanClass> classes,List<Bean> beans,List<scanAnnotationClass> scanAnnotationClasses){
        scanAspectClass sac = new scanAspectClass(classes,beans,scanAnnotationClasses);
        return sac;
    }

    @Override
    public authScanner Authorization(CallGraphMain callGraphMain,List<scanClass> classes,List<Bean> beans){
        authScanner scanner = new authScanner(classes,beans);
        scanner.scan(Config.SPRING_JAR_PATH);
        //scanner.writeIntoJson();
        return scanner;
    }

    @Override
    public validScanner Validation(CallGraphMain callGraphMain,List<scanClass> classes){
        validScanner scanner = new validScanner(classes);
        scanner.scan(callGraphMain,Config.SPRING_JAR_PATH);
        return scanner;
    }

    @Override
    public ConditionOnScanner Condition(CallGraphMain callGraphMain,List<scanClass> classes){
        ConditionOnScanner scanner = new ConditionOnScanner(classes);
        scanner.scan(callGraphMain,Config.SPRING_JAR_PATH);
        return scanner;
    }

    @Override
    public cacheScanner Cache(CallGraphMain callGraphMain,List<scanClass> classes){
        cacheScanner scanner = new cacheScanner(classes);
        scanner.scan(callGraphMain,Config.SPRING_JAR_PATH);
        return scanner;
    }
}
