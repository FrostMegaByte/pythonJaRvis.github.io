package Main;

import AspectJ.scanAspectClass;
import Authorization.authScanner;
import Cache.cacheScanner;
import ConditionOn.ConditionOnScanner;
import IOC.bean.Bean;
import IOC.bean.BeanScanner;
import MVC.controllerScanner;
import Validator.validScanner;
import dataStructure.scanAnnotationClass;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.impurity.bean.Node;

import java.util.List;
import java.util.Map;

public interface IModule {
    public void writeIntoJson(List<scanClass> classes);
    public BeanScanner IOC(List<scanClass> classes,Map<String,List<String>> annotationMap) throws Exception;
    public controllerScanner MVC(CallGraphMain callGraphMain, List<scanClass> classes);
    public scanAspectClass AOP(CallGraphMain callGraphMain, List<scanClass> classes, List<Bean> beans, List<scanAnnotationClass> scanAnnotationClasses);
    public authScanner Authorization(CallGraphMain callGraphMain, List<scanClass> classes, List<Bean> beans);
    public validScanner Validation(CallGraphMain callGraphMain, List<scanClass> classes);
    public ConditionOnScanner Condition(CallGraphMain callGraphMain, List<scanClass> classes);
    public cacheScanner Cache(CallGraphMain callGraphMain, List<scanClass> classes);
}
