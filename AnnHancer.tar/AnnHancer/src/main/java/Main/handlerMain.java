package Main;

import Cache.cacheScanner;
import ConditionOn.ConditionOnScanner;
import IOC.bean.Bean;
import IOC.bean.BeanScanner;
import IOC.bean.UsedBeanScanner;
import MVC.controllerScanner;
import Validator.validScanner;
import base.config.Config;
import base.util.CountUtil;
import base.util.JsonUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import Authorization.authScanner;
import dataStructure.scanClass;
import dataStructure.scanField;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.AbstractNode;
import edu.fdu.se.callgraph.impurity.bean.Node;
import scanAnnotation.scan.defaultScanAnnotation;
import soot.Body;
import soot.SootMethod;
import soot.Unit;

import java.io.File;
import java.util.*;

public class handlerMain {

    public static void main(String[] args) throws Exception{
        long start = System.currentTimeMillis();
        if(args.length != 4){
            return;
        }
        run(args);
        long end = System.currentTimeMillis();
        double min = (double)(end - start) / 60000;
        System.out.println(min);
    }

    public static void run(String[] args) throws Exception{
        Config.setProperty(args[0]);
        Config.set(args[2],args[1],args[3]);

        //
        defaultScanAnnotation dsa = new defaultScanAnnotation();
        dsa.scanJar();
        List<scanClass> list = dsa.getScanClasses();
        CallGraphMain callGraphMain = new CallGraphMain(Config.JAVA_DOC_PATH,Config.LOG_PATH,Config.RT_JAR);

        IModule module = new Module();
//        module.writeIntoJson(list);


        //1.-------------------------------IOC&Condition
        //IOC Bean Constructor//
        BeanScanner scanner = module.IOC(list,dsa.getProjectAnnotationMap());
//
//        //scanner.filter();
//        List<Bean> beans = scanner.getAllBeans();
//        int count = 0;
//        List<String> names = new ArrayList<>();
//        for(Bean bean : beans){
//            if(names.contains(bean.getBeanName())){
//                continue;
//            }
//            names.add(bean.getBeanName());
//        }
//        List<Node> beanNodes = scanner.getMethodCount(callGraphMain);
//        int ioc_indirect = CountUtil.getCount(beanNodes);
//
//
//        //condition
//        ConditionOnScanner condition = module.Condition(callGraphMain,list);
//        List<Node> conditionNodes = condition.getConditionNodes();
//        double time1 = condition.getTime();
//        int condition_count = CountUtil.getCount(conditionNodes);
//
//
//        //Autowire
//        UsedBeanScanner usedBeanScanner = new UsedBeanScanner(list,scanner.getAllBeans());
//        //处理@Autowired
//        usedBeanScanner.scanUseBeanClasses();
//        usedBeanScanner.handleUseBeanClasses();
//        List<Node> unusedNodes = usedBeanScanner.getUnusedNodes(callGraphMain,dsa.getMap());
//        double time2 = usedBeanScanner.getTime();
//        int autowire_count = CountUtil.getCount(unusedNodes);
//
//
//        //2.--------------------------------MVC&AOP&Cache&Security&Validation
        controllerScanner cs = module.MVC(callGraphMain,scanner.getControllerClasses());
//        int count = cs.checkExceptions();
//        int catchNumbers = cs.getCatchNumbers();
//        List<Node> requestRoots = cs.getCiaMethods();
//        List<Node> exceptionNodes = cs.getExceptionNodes();
//        double time3 = cs.getTime();
//        int req_count = CountUtil.getCount(requestRoots);
//        int exc_count = CountUtil.getCount(exceptionNodes);

//        Map<String,AbstractNode> allNodes = new HashMap<>();
//        Queue<Node> queue = new LinkedList<>();
//        queue.addAll(requestRoots);
//        while(!queue.isEmpty()){
//            Node node = queue.poll();
//            allNodes.put(node.getMethodSignatureFull(),node);
//            for(AbstractNode child : node.getChildren()){
//                queue.add((Node) child);
//            }
//        }
//
//        //AOP general&Security
//        Map<scanMethod,List<scanMethod>> AOPMap =  module.AOP(callGraphMain,list,scanner.getAllBeans(),dsa.getScanAnnotationClasses()).scan(Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + "_AOP.json");;
//        Map<scanMethod,List<scanMethod>> SecurityMap = module.Security(callGraphMain,list,scanner.getAllBeans());
//
//        for(Node root : requestRoots){
//            dfs(root,AOPMap,SecurityMap,allNodes,callGraphMain);
//        }
//
        //validation
//        validScanner validationScanner = module.Validation(callGraphMain,list);
//        List<Node> validNodes = validationScanner.getValidNodes();
//        double time4 = validationScanner.getTime();
//        int valid_count = CountUtil.getCount(validNodes);
//
//        //AOP general test
//        long start = System.currentTimeMillis();
//        Map<scanMethod,List<scanMethod>> AOPMap =  module.AOP(callGraphMain,list,scanner.getAllBeans(),dsa.getScanAnnotationClasses()).scan(Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + "_AOP.json");
//        JSONArray arr = new JSONArray();
//        for(scanMethod sm : AOPMap.keySet()){
//            for(scanMethod m : AOPMap.get(sm)){
//                if(m != null && !arr.contains(m.getMethodFullName())){
//                    arr.add(m.getMethodFullName());
//                }
//            }
//        }
//        List<Node> ciaMethods = callGraphMain.generateCallGraph(arr,Config.JAR_PATH).getCiaMethod();
//        long end = System.currentTimeMillis();
//        double time5 = (double)(end - start) / 60000;
//        int aop_count = CountUtil.getCount(ciaMethods);
//
//        //cache test--------------------
//        cacheScanner cachedScanner = module.Cache(callGraphMain,list);
//        List<Node> cacheNodes = cachedScanner.getAllNodes();
//        double time6 = cachedScanner.getTime();
//        int cache_count = CountUtil.getCount(cacheNodes);
//
//        //Security test----------------
//        securityScanner SecurityScanner = module.Security(callGraphMain,list,scanner.getAllBeans());
//        long s = System.currentTimeMillis();
//        List<Node> securityNodes = SecurityScanner.getRoots(callGraphMain);
//        long e = System.currentTimeMillis();
//        double time7 = (double)(e - s) / 60000;
//        double sum = time1 + time2 + time3 + time4 + time5 + time6 + time7;
//        int security_count = CountUtil.getCount(securityNodes);
        System.out.println("test");


        //compare(beans);
        compare2(scanner.getControllerClasses());
    }

    public static void compare(List<Bean> allBeans){
        JSONObject object = JsonUtil.readJsonObject(Config.OUTPUT_PATH + File.separator + "class.json");
        JSONArray arr = object.getJSONArray(Config.PROJECT_NAME);
        int ground_truth = arr.size();
        int count = 0;
        List<String> names = new ArrayList<>();
        List<String> falseNames = new ArrayList<>();
        for(Bean bean : allBeans){
            if(names.contains(bean.getBeanName())){
                continue;
            }
            names.add(bean.getBeanName());
            String type = bean.getBeanType();
            String name = type;
            String prefix = "BOOT-INF.classes.";
            if(type.contains(prefix)){
                name = type.substring(prefix.length());
            }
            if(arr.contains(name)){
                count++;
            } else{
                falseNames.add(name);
            }

        }
        int myCount = names.size();
        System.out.println("test");
    }

    public static void compare2(List<scanClass> classes){
        JSONObject object = JsonUtil.readJsonObject(Config.OUTPUT_PATH + File.separator + "controller_class.json");
        JSONArray arr = object.getJSONArray(Config.PROJECT_NAME);
        int ground_truth = arr.size();
        int count = 0;
        List<String> names = new ArrayList<>();
        List<String> unused = new ArrayList<>();
        for(scanClass sc : classes){
            String name = sc.getName();
            String prefix = "BOOT-INF.classes.";
            if(name.contains(prefix)){
                name = name.substring(prefix.length());
            }
            if(names.contains(name)){
                continue;
            }
            if(arr.contains(name)){
                count++;
            } else{
                unused.add(name);
            }
            names.add(name);
        }
        System.out.println("test");
    }

    /**
     * @param root
     * @param AOPMap
     * @param SecurityMap
     * @param allNodes
     * @param callGraphMain
     */
    public static void dfs(Node root,Map<scanMethod,List<scanMethod>> AOPMap,Map<scanMethod,List<scanMethod>> SecurityMap,Map<String,AbstractNode> allNodes,CallGraphMain callGraphMain){
        String methodName = root.getMethodSignatureFull();
        JSONArray notGeneratedMethods = new JSONArray();
        List<AbstractNode> children = new ArrayList<>();
        for(scanMethod sm : AOPMap.keySet()){
            if(sm.getMethodFullName().equals(methodName)){
                if(allNodes.containsKey(sm.getMethodFullName())){
                    children.add(allNodes.get(sm.getMethodFullName()));
                } else{
                    notGeneratedMethods.add(sm.getMethodFullName());
                }
            }
        }
        for(scanMethod sm : SecurityMap.keySet()){
            if(sm.getMethodFullName().equals(methodName)){
                if(allNodes.containsKey(sm.getMethodFullName())){
                    children.add(allNodes.get(sm.getMethodFullName()));
                } else{
                    notGeneratedMethods.add(sm.getMethodFullName());
                }
            }
        }
        CallGraphBean callGraphBean = callGraphMain.generateCallGraph(notGeneratedMethods, Config.JAR_PATH);
        for(Node node : callGraphBean.getCiaMethod()){
            allNodes.put(node.getMethodSignatureFull(),node);
        }
        children.addAll(callGraphBean.getCiaMethod());
        List<AbstractNode> temp = root.getChildren();
        temp.addAll(children);
        root.setChildren(temp);

        for(AbstractNode child : root.getChildren()){
            dfs((Node) child,AOPMap,SecurityMap,allNodes,callGraphMain);
        }
    }
}
