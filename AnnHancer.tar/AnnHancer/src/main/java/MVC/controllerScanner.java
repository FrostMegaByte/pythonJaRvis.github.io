package MVC;

import base.config.Config;
import base.util.JsonUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.AbstractNode;
import edu.fdu.se.callgraph.impurity.bean.Node;
import org.springframework.util.AntPathMatcher;
import soot.Body;
import soot.SootMethod;
import soot.Unit;
import soot.tagkit.AnnotationArrayElem;
import soot.tagkit.AnnotationClassElem;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationStringElem;

import java.io.File;
import java.util.*;

public class controllerScanner {
    private List<scanClass> scanClasses;
    private List<scanControllerClass> controllerClasses = new ArrayList<>();
    private List<scanAdviceClass> adviceClasses = new ArrayList<>();
    private List<scanMethod> allRequestMethods = new ArrayList<>();
    private List<String> allExceptions = new ArrayList<>();

    private int catchNumbers = 0;

    private List<Node> ciaMethods = new ArrayList<>();

    private double time = 0;

    public controllerScanner(List<scanClass> scanClasses){
        this.scanClasses = scanClasses;
    }

    public double getTime(){
        return this.time;
    }

    /**
     *
     *
     * @param callGraphMain
     * @param jarName
     */
    public void scan(CallGraphMain callGraphMain,List<String> jarName){
        for(scanClass sc : scanClasses){
            for(annotation a : sc.getClassAnnotations()){
                if(a.getName().equals("Lorg/springframework/web/bind/annotation/RestController;")
                || a.getName().equals("Lorg/springframework/stereotype/Controller;")){
                    scanControllerClass scc = new scanControllerClass(sc);
                    scc.scan(callGraphMain);
                    controllerClasses.add(scc);
                } else if(a.getName().equals("Lorg/springframework/web/bind/annotation/ControllerAdvice;")
                || a.getName().equals("Lorg/springframework/web/bind/annotation/RestControllerAdvice;")){
                    scanAdviceClass sac = new scanAdviceClass(sc,a);
                    sac.scan(callGraphMain,jarName);
                    adviceClasses.add(sac);
                    allExceptions.addAll(sac.getExceptions());
                }
            }
        }
        adviceClassScanner();
        generateCallGraph(callGraphMain,jarName);
//        writeIntoJson();
    }

    /**
     *
     */
    public void writeIntoJson(){
        JSONObject res = new JSONObject();
        JSONArray ControllerClasses = new JSONArray();
        JSONArray ExceptionClasses = new JSONArray();
        for(scanControllerClass scc : controllerClasses){
            JSONObject controllerClass = new JSONObject();
            controllerClass.put(scc.getName(),scc.getControllerMethods());
            ControllerClasses.add(controllerClass);
        }
        for(scanAdviceClass sac : adviceClasses){
            JSONObject adviceClass = new JSONObject();
            adviceClass.put(sac.getName(),sac.getExceptionHandlerMethods());
            ExceptionClasses.add(adviceClass);
        }
        res.put("ControllerClasses",ControllerClasses);
        res.put("ExceptionHandlers",ExceptionClasses);
        JsonUtil.writeJson(Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + "_MVC.json",res,true);
    }

    /**
     *
     */
    private void adviceClassScanner(){
        for(scanAdviceClass sac : adviceClasses){
            annotation a = sac.getAnnotation();
            if(a.getParams().size() == 0){
                for(scanControllerClass scc : controllerClasses){
                    scc.addExceptionHandlers(sac.getExceptionHandlers());
                }
            } else{
                for(AnnotationElem elem : a.getParams()){
                    String name = elem.getName();
                    if(name.equals("value") || name.equals("basePackages")){
                        AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                        for(AnnotationElem packageName : arr.getValues()){
                            String packagePrefix = ((AnnotationStringElem) packageName).getValue();
                            for(scanControllerClass scc : controllerClasses){
                                if(scc.getName().startsWith(packagePrefix)){
                                    scc.addExceptionHandlers(sac.getExceptionHandlers());
                                }
                            }
                        }
                    }
                    else if(name.equals("basePackageClasses")){
                        AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                        for(AnnotationElem classElem : arr.getValues()){
                            String desc = ((AnnotationClassElem) classElem).getDesc();
                            String classPackageName = getClassPackageName(desc);
                            for(scanControllerClass scc : controllerClasses){
                                if(scc.getName().startsWith(classPackageName)){
                                    scc.addExceptionHandlers(sac.getExceptionHandlers());
                                }
                            }
                        }
                    }
                    else if(name.equals("assignableTypes")){
                        AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                        for(AnnotationElem classElem : arr.getValues()){
                            String desc = ((AnnotationClassElem) classElem).getDesc();
                            String classPackageName = getClassName(desc);
                            for(scanControllerClass scc : controllerClasses){
                                if(scc.getName().equals(classPackageName)){
                                    scc.addExceptionHandlers(sac.getExceptionHandlers());
                                }
                            }
                        }
                    }
                    else if(name.equals("annotations")){
                        AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                        for(AnnotationElem classElem : arr.getValues()){
                            String desc = ((AnnotationClassElem) classElem).getDesc();
                            String annotationName = getClassName(desc);
                            for(scanControllerClass scc : controllerClasses){
                                for(annotation an : scc.getClassAnnotations()){
                                    if(an.getName().equals(annotationName)){
                                        scc.addExceptionHandlers(sac.getExceptionHandlers());
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     *
     * @param desc
     * @return
     */
    private String getClassPackageName(String desc){
        //
        String tempClassName = desc.substring(1,desc.length() - 1);
        String[] str = tempClassName.split("/");
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < str.length - 1; i++){
            sb.append(str);
            if(i != str.length - 2){
                sb.append(".");
            }
        }
        return sb.toString();
    }

    private String getClassName(String desc){
        //
        String tempClassName = desc.substring(1,desc.length() - 1).replace("/",".");
        return tempClassName;
    }

    /**
     * @param URL
     * @return
     */
    public Node match(String URL){
        for(scanControllerClass scc : controllerClasses){
            Map<scanMethod,List<String>> patternMap = scc.getPatterns();
            for(scanMethod sm : patternMap.keySet()){
                List<String> patterns = patternMap.get(sm);
                for(String pattern : patterns){
                    AntPathMatcher matcher = new AntPathMatcher();
                    if(matcher.match(pattern,URL)){
                        String methodName = sm.getName();
                        for(Node node : ciaMethods){
                            if(node.getMethod().getName().equals(methodName)){
                                return node;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * @return
     */
    public void generateCallGraph(CallGraphMain callGraphMain,List<String> jarName){
        Map<scanControllerClass,List<scanMethod>> methods = getControllerMethods();
        //
        Map<String,scanControllerClass> map = new HashMap<>();
        long start = System.currentTimeMillis();
        JSONArray root = new JSONArray();
        for(scanControllerClass scc : methods.keySet()){
            for(scanMethod sm : methods.get(scc)){
                root.add(sm.getMethodFullName());
                map.put(sm.getSootMethod().toString(),scc);
            }
        }

        CallGraphBean callGraphBean = callGraphMain.generateCallGraph(root,jarName);
        long end = System.currentTimeMillis();
        this.time += (double)(end - start) / 60000;
        ciaMethods = callGraphBean.getCiaMethod();
        //
//        for(Node node : ciaMethods){
//            List<AbstractNode> children = node.getChildren();
//            String methodName = node.getMethod().toString();
//            scanControllerClass scc = map.get(methodName);
//            if(scc.getParamGeneratedNodes().containsKey(methodName)){
//                children.addAll(scc.getParamGeneratedNodes().get(methodName));
//            }
//            children.addAll(scc.getExceptionHandlers());
//            node.setChildren(children);
//        }
    }


    public Map<scanControllerClass,List<scanMethod>> getControllerMethods(){
        Map<scanControllerClass,List<scanMethod>> res = new HashMap<>();
        for(scanControllerClass scc : controllerClasses){
            res.put(scc,new ArrayList<>(scc.getPatterns().keySet()));
            allRequestMethods.addAll((scc.getPatterns().keySet()));
        }
        return res;
    }

    public List<Node> getCiaMethods(){
        return this.ciaMethods;
    }

    /**
     *
     */
    public int checkExceptions(){
        int count = 0;
        for(String exception : allExceptions){
            if(isValidException(exception)){
                count++;
            }
        }
        return count;
    }

    public boolean isValidException(String exception){
        for(Node root : ciaMethods){
            //
            Queue<Node> queue = new LinkedList<>();
            queue.add(root);
            //
            List<String> names = new ArrayList<>();
            names.add(root.toString());
            while(!queue.isEmpty()){
                //
                Node cur = queue.poll();
                if(cur.getChildren() == null || cur.getChildren().size() == 0){
                    continue;
                }
                for(AbstractNode child : cur.getChildren()){
                    //
                    if(names.contains(child.toString())){
                        continue;
                    }
                    names.add(child.toString());
                    //
                    String className = ((Node) child).getDeclaringClass();
                    if(className.endsWith(exception)){
                        this.catchNumbers++;
                        List<SootMethod> methods = new ArrayList<>();
                        dfs(root,methods,child.toString());
                        List<String> catchExceptions = containsTryCatch(methods);
                        for(String unit : catchExceptions){
                            if(unit.contains(exception)){
                                return false;
                            }
                        }
                    }
                    queue.add((Node) child);
                }
            }
        }
        return true;
    }

    /**
     *
     * @param root
     * @param chain
     * @param target
     * @return
     */
    private boolean dfs(Node root,List<SootMethod> chain,String target){
        if(chain.contains(root.getMethod())){
            return false;
        }
        if(root.toString().equals(target)){
            chain.add(root.getMethod());
            return true;
        }
        if(root.getChildren() == null || root.getChildren().size() == 0){
            return false;
        }
        chain.add(root.getMethod());
        for(AbstractNode child : root.getChildren()){
            if(dfs((Node)child,chain,target)){
                return true;
            }
        }
        chain.remove(chain.size() - 1);
        return false;
    }

    /**
     *
     * @param methods
     * @return
     */
    private List<String> containsTryCatch(List<SootMethod> methods){
        List<String> res = new ArrayList<>();
        for(SootMethod method : methods){
            boolean hasCatch = false;
            try{
                Body body = method.getActiveBody();
                for(Unit u : body.getUnits()){
                    String s = u.toString();
                    if(s.contains("caughtexception")){
                        hasCatch = true;
                    }
                    if(hasCatch & s.contains("Exception")){
                        res.add(s);
                    }
                }
            }catch(Exception e){
                System.out.println("no method body");
            }
        }
        return res;
    }

    public List<scanMethod> getAllRequestMethods(){
        return this.allRequestMethods;
    }

    public List<Node> getExceptionNodes(){
        List<Node> res = new ArrayList<>();
        for(scanAdviceClass sac : adviceClasses){
            res.addAll(sac.getExceptionHandlers());
        }
        return res;
    }

    public int getCatchNumbers(){
        return this.catchNumbers;
    }

    public static void main(String[] args){
        AntPathMatcher matcher = new AntPathMatcher();
        System.out.println(matcher.match("/api/{id}","/api/1"));
        System.out.println(matcher.match("/student/{name:\\w+}-{age:\\d+}","/student/wangwu-33"));
    }
}
