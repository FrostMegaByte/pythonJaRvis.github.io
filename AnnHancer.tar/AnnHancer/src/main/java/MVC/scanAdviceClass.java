package MVC;

import com.alibaba.fastjson.JSONArray;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import dataStructure.annotation;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.Node;
import soot.tagkit.AnnotationArrayElem;
import soot.tagkit.AnnotationClassElem;
import soot.tagkit.AnnotationElem;

import java.util.ArrayList;
import java.util.List;

public class scanAdviceClass {
    private scanClass sc;
    private annotation a;
    private List<Node> exceptionHandlers = new ArrayList<>();
    private List<String> exceptionHandlerMethods = new ArrayList<>();
    private List<String> exceptions = new ArrayList<>();

    public scanAdviceClass(scanClass sc,annotation a){
        this.sc = sc;
        this.a = a;
    }

    public void scan(CallGraphMain callGraphMain, List<String> jarName){
        JSONArray exceptionMethods = new JSONArray();
        for(scanMethod sm : sc.getScanMethods()){
            for(annotation a : sm.getMethodAnnotations()){
                if(a.getName().equals("Lorg/springframework/web/bind/annotation/ExceptionHandler;")){
                    exceptionMethods.add(sm.getMethodFullName());
                    exceptionHandlerMethods.add(sm.getMethodFullName());
                    handleAnnotation(a);
                }
            }
        }
        CallGraphBean callGraphBean = callGraphMain.generateCallGraph(exceptionMethods,jarName);
        exceptionHandlers.addAll(callGraphBean.getCiaMethod());
    }

    public void handleAnnotation(annotation a){
        for(AnnotationElem elem : a.getParams()){
            if(elem instanceof AnnotationArrayElem){
                for(AnnotationElem param : ((AnnotationArrayElem) elem).getValues()){
                    String name = ((AnnotationClassElem) param).getDesc();
                    String[] str = name.split("/");
                    String exception = str[str.length - 1];
                    exceptions.add(exception.substring(0,exception.length() - 1));
                }
            }
        }
    }

    public List<Node> getExceptionHandlers(){
        return this.exceptionHandlers;
    }

    public annotation getAnnotation(){
        return this.a;
    }

    public List<String> getExceptionHandlerMethods(){
        return exceptionHandlerMethods;
    }

    public String getName(){
        return sc.getName();
    }

    public List<String> getExceptions(){
        return this.exceptions;
    }
}
