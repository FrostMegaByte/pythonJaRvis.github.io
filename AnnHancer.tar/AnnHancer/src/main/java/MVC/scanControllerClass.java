package MVC;

import base.config.Config;
import com.alibaba.fastjson.JSONArray;
import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.Node;
import soot.tagkit.AnnotationArrayElem;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationStringElem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class scanControllerClass {
    private String classPattern;
    private Map<scanMethod, List<String>> methodPatternMap = new HashMap<>();
    private List<Node> exceptionHandlers = new ArrayList<>();

    private scanClass sc;
    private Map<String,String> controllerMethods = new HashMap<>();

    private List<scanMethod> paramGeneratedMethods = new ArrayList<>();
    private Map<String,List<Node>> paramGeneratedNodes = new HashMap<>();

    public scanControllerClass(scanClass sc) {
        this.sc = sc;
    }

    /**
     *
     */
    public void scan(CallGraphMain callGraphMain){
        for(annotation a : sc.getClassAnnotations()){
            if(isValid(a.getName())){
                handleClassRequest(a);
            }
        }
        for(scanMethod sm  : sc.getScanMethods()){
            for(annotation a : sm.getMethodAnnotations()){
                if(isValid(a.getName())){
                    controllerMethods.put(sm.getMethodFullName(),a.getName());
                    handleMethodRequest(a,sm);
                }
            }
            for(annotation a : sm.getParamAnnotations()){
                if(isValid(a.getName())){
                    paramGeneratedMethods.add(sm);
                }
            }
        }
        if(paramGeneratedMethods.size() != 0){
            JSONArray arr = new JSONArray();
            arr.add("org.springframework.web.reactive.result.method.annotation.handle(ServerWebExchange,Object)");
            CallGraphBean callGraphBean = callGraphMain.generateCallGraph(arr, Config.SPRING_JAR_PATH);
            for(scanMethod sm : paramGeneratedMethods){
                paramGeneratedNodes.put(sm.getMethodFullName(),callGraphBean.getCiaMethod());
            }
        }
    }

    public Map<String,List<Node>> getParamGeneratedNodes(){
        return this.paramGeneratedNodes;
    }

    public Map<String,String> getControllerMethods(){
        return controllerMethods;
    }

    /**
     * @param name
     * @return
     */
    private boolean isValid(String name){
        if(name.equals("Lorg/springframework/web/bind/annotation/RequestMapping;")
                || name.equals("Lorg/springframework/web/bind/annotation/GetMapping;")
                || name.equals("Lorg/springframework/web/bind/annotation/PostMapping;")
                || name.equals("Lorg/springframework/web/bind/annotation/DeleteMapping;")
                || name.equals("Lorg/springframework/web/bind/annotation/PutMapping;")
                || name.equals("Lorg/springframework/web/bind/annotation/PatchMapping;")
                || name.equals("Lorg/springframework/web/bind/annotation/ModelAttribute;")){
            return true;
        }
        return false;
    }

    /**
     * @param a
     */
    private List<String> handleRequest(annotation a){
        List<String> res = new ArrayList<>();
        for(AnnotationElem elem : a.getParams()){
            if(elem.getName().equals("value")){
                AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                for(AnnotationElem url : arr.getValues()){
                    res.add(((AnnotationStringElem) url).getValue());
                }
            }
        }
        return res;
    }

    /**
     * @param a
     */
    private void handleClassRequest(annotation a){
        List<String> pattern = handleRequest(a);
        classPattern = pattern.get(0);
    }

    /**
     */
    private void handleMethodRequest(annotation a,scanMethod sm){
        List<String> patterns = handleRequest(a);
        if(classPattern == null){
            methodPatternMap.put(sm,patterns);
        } else{
            List<String> fullPatterns = new ArrayList<>();
            for(String pattern : patterns){
                fullPatterns.add(classPattern + "/" + pattern);
            }
            methodPatternMap.put(sm,fullPatterns);
        }
    }

    /**
     * @return
     */
    public Map<scanMethod,List<String>> getPatterns(){
        return methodPatternMap;
    }

    public void addExceptionHandlers(List<Node> methods){
        exceptionHandlers.addAll(methods);
    }

    public String getName(){
        return sc.getName();
    }

    public List<annotation> getClassAnnotations(){
        return sc.getClassAnnotations();
    }

    public List<Node> getExceptionHandlers(){
        return this.exceptionHandlers;
    }
}
