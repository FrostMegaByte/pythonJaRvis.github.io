package Authorization;

import IOC.bean.Bean;
import base.config.Config;
import base.util.JsonUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.Node;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationStringElem;
import scanAnnotation.scan.defaultScanAnnotation;

import java.io.File;
import java.util.*;

public class authScanner {
    private List<scanClass> classes;
    private List<Bean> beans;
    private Map<scanMethod, Map<scanMethod,String>> res = new HashMap<>();

    public authScanner(List<scanClass> classes,List<Bean> beans){
        this.classes = classes;
        this.beans = beans;
    }

    public void scan(List<String> jarList){
        String jarPath = "";
        for(String jarName : jarList){
            if(jarName.contains("spring-security-core")){
                jarPath = jarName;
            }
        }
        defaultScanAnnotation dsa = new defaultScanAnnotation();
        dsa.scanCommonJar(jarPath);
        List<scanClass> list = dsa.getScanClasses();
        List<scanMethod> methods = new ArrayList<>();
        for(scanClass sc : list){
            if(sc.getName().equals("org.springframework.security.access.expression.SecurityExpressionRoot")){
                methods.addAll(sc.getScanMethods());
            }
        }
        for(scanClass sc : classes){
            for(scanMethod sm : sc.getScanMethods()){
                for(annotation a : sm.getMethodAnnotations()){
                    String name = a.getName();
                    if(name.equals("Lorg/springframework/security/access/prepost/PreAuthorize;")
                    || name.equals("Lorg/springframework/security/access/prepost/PreFilter;")
                    || name.equals("Lorg/springframework/security/access/prepost/PostFilter;")
                    || name.equals("Lorg/springframework/security/access/prepost/PostAuthorize;")){
                        handleSecurityAnnotation(a,sm,methods);
                    }
                }
            }
        }
    }

    /**
     * AND OR NOT
     * @param a
     * @param sm
     */
    private void handleSecurityAnnotation(annotation a,scanMethod sm,List<scanMethod> methods){
        res.put(sm,new HashMap<>());
        for(AnnotationElem elem : a.getParams()){
            String pattern = ((AnnotationStringElem) elem).getValue();
            List<String> list = handlePattern(pattern);
            for(String methodName : list){
                //
                if(methodName.contains("@")){
                    String[] beanMethodName = methodName.split("\\.");
                    String beanName = beanMethodName[0].substring(1);
                    String methodShortName = beanMethodName[1];
                    for(Bean bean : beans){
                        if(bean.getBeanName().equals(beanName)){
                            for(scanMethod method : bean.getScanClass().getScanMethods()){
                                if(method.getName().contains(methodShortName)){
                                    res.get(sm).put(method,a.getName());
                                }
                            }
                        }
                    }
                } else{
                    for(scanMethod method : methods){
                        if(method.getName().contains(methodName)){
                            res.get(sm).put(method,a.getName());
                        }
                    }
                }
            }
        }
    }

    /**
     *
     * @param pattern
     * @return
     */
    private List<String> handlePattern(String pattern){
        List<String> res = new ArrayList<>();
        Queue<String> queue = new LinkedList<>();
        queue.add(pattern);
        while(!queue.isEmpty()){
            String tmp = queue.poll();
            String[] separators = new String[]{"and","or","not"};
            boolean isValid = true;
            for(String separator : separators){
                if(tmp.contains(separator)){
                    String[] str = tmp.split(separator);
                    for(String s : str){
                        queue.add(s);
                    }
                    isValid = false;
                    break;
                }
            }
            if(isValid){
                int index = 0;
                while(tmp.charAt(index) == '(') {
                    index++;
                }
                String methodPattern = tmp.substring(index).trim();
                if(!methodPattern.contains("(")){
                    continue;
                } else{
                    int i = methodPattern.indexOf('(');
                    res.add(methodPattern.substring(0,i));
                }

            }
        }
        return res;
    }

    public void writeIntoJson(){
        JSONObject object = new JSONObject();
        for(scanMethod sm : res.keySet()){
            JSONObject tmp = new JSONObject();
            for(scanMethod method : res.get(sm).keySet()){
                tmp.put(method.getMethodFullName(),res.get(sm).get(method));
            }
            object.put(sm.getMethodFullName(),tmp);
        }
        JsonUtil.writeJson(Config.OUTPUT_PATH + File.separator + Config.PROJECT_NAME + "_Security.json",object,true);
    }

    public Map<scanMethod,List<scanMethod>> getCiaMethods(){
        Map<scanMethod,List<scanMethod>> map = new HashMap<>();
        for(scanMethod sm : res.keySet()){
            map.put(sm,new ArrayList<>());
            for(scanMethod method : this.res.get(sm).keySet()){
                map.get(sm).add(method);
            }
        }
        return map;
    }

    public List<Node> getRoots(CallGraphMain callGraphMain){
        JSONArray arr = new JSONArray();
        Map<scanMethod,List<scanMethod>> map = getCiaMethods();
        for(scanMethod sm : map.keySet()){
            for(scanMethod method : map.get(sm)){
                arr.add(method.getMethodFullName());
            }
        }
        List<String> jarList = new ArrayList<>();
        jarList.addAll(Config.JAR_PATH);
        jarList.addAll(Config.SPRING_JAR_PATH);
        CallGraphBean callGraphBean = callGraphMain.generateCallGraph(arr,jarList);
        return callGraphBean.getCiaMethod();
    }
}
