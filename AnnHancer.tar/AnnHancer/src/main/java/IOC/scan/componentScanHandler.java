package IOC.scan;

import AspectJ.AspectPathMatcher;
import base.config.Config;
import dataStructure.scanClass;
import dataStructure.annotation;
import org.springframework.util.AntPathMatcher;
import soot.SootClass;
import soot.tagkit.*;
import soot.util.Chain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 普通情况：类注解componentScan componentScans
 * 特殊情况：SpringBootApplication Import
 */
public class componentScanHandler {
    List<scanClass> componentScanClasses;
    Map<String,scanClass> componentScanMap;
    private List<String> classes = new ArrayList<>();
    private Map<String,List<String>> annotationMap;

    public componentScanHandler(List<scanClass> scanClasses,Map<String,List<String>> annotationMap){
        componentScanClasses = scanClasses;
        componentScanMap = new HashMap<>();
        for(scanClass sc : scanClasses){
            String name = sc.getName();
            componentScanMap.put(name,sc);
        }
        this.annotationMap = annotationMap;
    }

    public List<scanClass> getScannedClasses(){
        List<scanClass> res = new ArrayList<>();
        for(String name : classes){
            res.add(componentScanMap.get(name));
        }
        return res;
    }

    /**
     */
    public void handleComponentScanAnnotations(){
        for(scanClass sc : componentScanClasses){
            for(annotation a : sc.getClassAnnotations()){
                if(a.getName().equals("Lorg/springframework/context/annotation/ComponentScans;")){
                    handleComponentScans(a,sc);
                }
                else if(a.getName().equals("Lorg/springframework/context/annotation/ComponentScan;")){
                    handleComponentScan(a,sc);
                }
                else if(a.getName().equals("Lorg/springframework/boot/autoconfigure/SpringBootApplication;")){
                    handleComposedAnnotation(a,sc);
                } else if(annotationMap.containsKey("Lorg/springframework/boot/autoconfigure/SpringBootApplication;")){
                    for(String s : annotationMap.get("Lorg/springframework/boot/autoconfigure/SpringBootApplication;")){
                         if(s.contains(getAnnotationName(a.getName()))){
                            handleComposedAnnotation(a,sc);
                        }
                    }
                }
                else if(a.getName().equals("Lorg/springframework/context/annotation/Import;")){
                    handleImportAnnotation(a,sc);
                }
            }
        }
    }

    /**
     * @param name
     * @return
     */
    public String getAnnotationName(String name){
        String temp = name.substring(1,name.length() - 1);
        return temp.replace("/",".");
    }

    private boolean isClassWithBean(String className){
        scanClass sc = componentScanMap.get(className);
        if(sc.isInterface()){
            return false;
        }
        for(SootClass interfaceClass : sc.getInterfaces()){
            if(interfaceClass.getName().equals("java.lang.annotation.Annotation")) {
                return false;
            }
        }
        List<annotation> classAnnotations = sc.getClassAnnotations();
        for(annotation a : classAnnotations){
            if(a.getName().equals("Lorg/springframework/stereotype/Component;") ||
                    a.getName().equals("Lorg/springframework/stereotype/Service;") ||
                    a.getName().equals("Lorg/springframework/stereotype/Repository;") ||
                    a.getName().equals("Lorg/springframework/web/bind/annotation/RestController;") ||
                    a.getName().equals("Lorg/springframework/stereotype/Controller;") ||
                    a.getName().equals("Lorg/springframework/web/bind/annotation/ControllerAdvice;") ||
                    a.getName().equals("Lorg/springframework/web/bind/annotation/RestControllerAdvice;")){
                return true;
            }
            else if(a.getName().equals("Lorg/springframework/context/annotation/Configuration;")){
                return true;
            } else if(annotationMap.containsKey("Lorg/springframework/stereotype/Component;")){
                for(String s : annotationMap.get("Lorg/springframework/stereotype/Component;")){
                    if(s.contains(getAnnotationName(a.getName()))){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * @param a
     */
    private void handleImportAnnotation(annotation a,scanClass sc){
        List<AnnotationElem> params = a.getParams();
        for(AnnotationElem param : params){
            AnnotationArrayElem classes = (AnnotationArrayElem) param;
            for(AnnotationElem className : classes.getValues()){
                //Lcom/example/demo/Demo1Application; 需要处理 搜索很麻烦
                String name = ((AnnotationClassElem) className).getDesc();
                String newName = handleClassName(name).replace("/",".");
                for(scanClass csc : componentScanClasses){
                    if(csc.getName().contains(newName)){
                        this.classes.add(newName);
                        this.classes.add(sc.getName());
                    }
                }
            }
        }
    }

    /**
     * @param className
     * @return
     */
    private String handleClassName(String className){
        //根据JVM说明 这里的className 应该是L + name + ;
        return className.substring(1,className.length() - 1);
    }

    /**
     * @param a
     */
    private void handleComposedAnnotation(annotation a,scanClass sc){
        if(!sc.getName().contains("BOOT-INF.classes.") || sc.isInterface()){
            return;
        }
        List<AnnotationElem> params = a.getParams();
        List<String> basePackages = new ArrayList<>();
        List<String> baseClasses = new ArrayList<>();
        for(AnnotationElem elem : params){
            if(elem.getName().equals("scanBasePackages")){
                if(elem instanceof AnnotationArrayElem){
                    AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                    for(AnnotationElem ae : arr.getValues()){
                        AnnotationStringElem annotationElem = (AnnotationStringElem) ae;
                        String packageName = annotationElem.getValue();
                        if(packageName.contains("$")){
                            int l = packageName.indexOf('{');
                            int r = packageName.indexOf("}");
                            try{
                                basePackages.add("cn.iocoder.yudao" + packageName.substring(r + 1));
                            }catch(Exception e){
                                e.printStackTrace();
                            }
                        } else{
                            basePackages.add(packageName);
                        }
                    }
                }
            }
            else if(elem.getName().equals("scanBasePackageClasses")) {
                if (elem instanceof AnnotationArrayElem) {
                    AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                    for (AnnotationElem ae : arr.getValues()) {
                        AnnotationClassElem annotationElem = (AnnotationClassElem) ae;
                        String className = annotationElem.getDesc();
                        String[] str = handleClassName(className).split("/");
                        StringBuilder sb = new StringBuilder();
                        for(int i = 0; i < str.length - 1; i++){
                            sb.append(str[i]).append(".");
                        }
                        basePackages.add(sb.toString());
                    }
                }
            }
        }
        //BOOT-INF.classes.com.example.demo.DemoApplication
        String applicationName = sc.getName();
        String[] str = applicationName.split("\\.");
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < str.length - 1; i++){
            sb.append(str[i]).append(".");
        }
        String prefix = "BOOT-INF.classes.";
        String applicationPackageName = sb.toString().substring(prefix.length());
        basePackages.add(applicationPackageName);
        for(scanClass scanClass : componentScanClasses){
            for(String packageName : basePackages){
                if(scanClass.getName().contains(packageName)){
                    baseClasses.add(scanClass.getName());
                }
            }
        }
        for(String className : baseClasses){
            if(isClassWithBean(className)){
                classes.add(className);
            }
        }
    }

    /**
     * @param a
     */
    private void handleComponentScans(annotation a,scanClass sc){
        //value default {}
        List<AnnotationElem> elems = a.getParams();
        for(AnnotationElem elem : elems){
            if(elem.getName().equals("value")){
                if(elem instanceof AnnotationArrayElem){
                    AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                    for(AnnotationElem ae : arr.getValues()){
                        AnnotationAnnotationElem annotationElem = (AnnotationAnnotationElem) ae;
                        AnnotationTag tag = annotationElem.getValue();
                        handleComponentScan(new annotation(tag.getType(),new ArrayList<>(tag.getElems())),sc);
                    }
                }
                else if(elem instanceof AnnotationAnnotationElem){
                    AnnotationAnnotationElem annotationElem = (AnnotationAnnotationElem) elem;
                    AnnotationTag tag = annotationElem.getValue();
                    handleComponentScan(new annotation(tag.getType(),new ArrayList<>(tag.getElems())),sc);
                }
            }
        }
    }

    /**
     * @param a
     */
    private void handleComponentScan(annotation a,scanClass sc){
        List<String> tempPackages = new ArrayList<>();
        List<String> tempClasses = new ArrayList<>();
        String expression = "";
        boolean defaultFilter = true;
        List<AnnotationElem> filters = new ArrayList<>();


        List<AnnotationElem> elems = a.getParams();
        for(AnnotationElem elem : elems){
            // value/basePackages default {}
            if(elem.getName().equals("value") || elem.getName().equals("basePackages")){
                if(elem instanceof AnnotationArrayElem){
                    AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                    for(AnnotationElem ae : arr.getValues()){
                        AnnotationStringElem str = (AnnotationStringElem) ae;
                            tempPackages.add(str.getValue());
                    }
                }
                else if(elem instanceof AnnotationStringElem){
                    tempPackages.add(((AnnotationStringElem) elem).getValue());
                }
                continue;
            }
            // basePackageClasses default {}
            if(elem.getName().equals("basePackageClasses")){
                AnnotationArrayElem arr = (AnnotationArrayElem) elem;
                for(AnnotationElem ae : arr.getValues()){
                    AnnotationClassElem str = (AnnotationClassElem) ae;
                    tempClasses.add(handleClassName(str.getDesc()));
                }
                continue;
            }


            //resourcePattern
            if(elem.getName().equals("resourcePattern")){
               expression  = ((AnnotationStringElem) elem).getValue();
               continue;
            }
            if(elem.getName().equals("useDefaultFilters")){
                defaultFilter = ((AnnotationBooleanElem) elem).getValue();
                continue;
            }
            if(elem.getName().equals("includeFilters") || elem.getName().equals("excludeFilters")){
                filters.add(elem);
            }
        }
        List<String> res = handleSimpleFilter(sc,tempPackages,tempClasses,expression,defaultFilter);
        for(String name : handleIncludeOrExcludeFilters(filters,res)){
            if(isClassWithBean(name)){
                classes.add(name);
            }
        }
    }

    /**
     * 粗略过滤
     * @param tempPackages
     * @param tempClasses
     * @param expression
     * @param defaultFilter
     */
    private List<String> handleSimpleFilter(scanClass sc,List<String> tempPackages,List<String> tempClasses,String expression,boolean defaultFilter){

        if(tempPackages.isEmpty() && tempClasses.isEmpty()){
            String name = sc.getName();
            String[] str = name.split("\\.");
            StringBuilder sb = new StringBuilder();
            for(int i = 0; i < str.length - 1; i++){
                sb.append(str[i]).append(".");
            }
            String prefix = "BOOT-INF.classes.";
            String packageName = sb.toString().substring(prefix.length());
            tempPackages.add(packageName);
        }

        for(String tempClass : tempClasses){
            String[] str = tempClass.split("/");
            StringBuilder sb = new StringBuilder();
            for(int i = 0; i < str.length - 1; i++){
                sb.append(str[i]).append(".");
            }
            tempPackages.add(sb.toString());
        }
        tempClasses.clear();

        //default resourcePattern = "**/*.class"
        List<String> classes = new ArrayList<>();
        for(scanClass csc : componentScanClasses){
            for(String packageName : tempPackages){
                if(csc.getName().contains(packageName)){
                    classes.add(csc.getName());
                }
            }
        }

        AntPathMatcher matcher = new AntPathMatcher();
        List<String> temp = new ArrayList<>();
        for(String name : classes){
            String patternName = name.replace(".","/");
            patternName += ".class";
            boolean isMatch = matcher.match(expression,patternName);
            if(isMatch){
                temp.add(name);
            }
        }
        if(expression.length() == 0){
            temp.addAll(classes);
        }


        //defaultFilter
        //@Component @Repository @Controller @Service

        if(defaultFilter){
            List<String> res = new ArrayList<>();
            for(String className : temp){
                scanClass tempClass = componentScanMap.get(className);
                List<annotation> annotations = tempClass.getClassAnnotations();
                for(annotation a : annotations){
                    String name = a.getName();
                    if(name.contains("Component") || name.contains("Repository")
                    || name.contains("Controller") || name.contains("Service") || name.contains("Configuration")){
                        res.add(className);
                    }
                }
            }
            return res;
        }
        return temp;
    }

    /**
     *     *     @ComponentScan(includeFilters = {
     *     *     @ComponentScan.Filter(type = FilterType.ANNOTATION, classes = {Controller.class, Service.class}),
     *     *     @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, classes = {SchoolDao.class}),
     *     *     @ComponentScan.Filter(type = FilterType.CUSTOM, classes = {MyTypeFilter.class}),
     *     *     @ComponentScan.Filter(type = FilterType.ASPECTJ, pattern = "spring.annotation..*"),
     *     *     @ComponentScan.Filter(type = FilterType.REGEX, pattern = "^[A-Za-z.]+Dao$")
     *     * },useDefaultFilters = false)
     * @param filters
     * @param tempClasses
     */
    private List<String> handleIncludeOrExcludeFilters(List<AnnotationElem> filters,List<String> tempClasses){
        for(AnnotationElem elem : filters){
            //include or exclude
            boolean isIncludeFilter;
            if(elem.getName().equals("includeFilters")){
                isIncludeFilter = true;
            }
            else{
                isIncludeFilter = false;
            }
            AnnotationArrayElem arr = (AnnotationArrayElem) elem;
            List<AnnotationElem> params = arr.getValues();
            for(AnnotationElem filterElem : params){
                AnnotationTag tag = ((AnnotationAnnotationElem) filterElem).getValue();
                List<AnnotationElem> filter = new ArrayList<>(tag.getElems());
                //enum ANNOTATION ASSIGNABLE CUSTOM ASPECTJ REGEX
                AnnotationEnumElem enumElem = (AnnotationEnumElem) filter.get(0);
                switch(enumElem.getConstantName()){
                    case "ANNOTATION":
                        tempClasses = handleANNOTATIONFilter(tempClasses,filter.get(1),isIncludeFilter);
                        break;
                    case "ASSIGNABLE_TYPE":
                        tempClasses = handleASSIGNABLEFilter(tempClasses,filter.get(1),isIncludeFilter);
                        break;
                    case "ASPECTJ":
                        List<scanClass> list = new ArrayList<>();
                        for(String name : tempClasses){
                            list.add(componentScanMap.get(name));
                        }
                        tempClasses = handleASPECTJFilter(list,filter.get(1),isIncludeFilter);
                        break;
                    case "REGEX":
                        tempClasses = handleREGEXFilter(tempClasses,filter.get(1),isIncludeFilter);
                        break;
                    case "CUSTOM":
                        //暂时不处理
                }
            }
        }
        return tempClasses;
    }

    /**
     * @param candidates
     * @param elem
     */
    private List<String> handleANNOTATIONFilter(List<String> candidates,AnnotationElem elem,boolean isIncludeFilter){
        List<String> res = new ArrayList<>();
        AnnotationArrayElem arr = (AnnotationArrayElem) elem;
        List<String> classNameFilter = new ArrayList<>();
        for(AnnotationElem classFilter : arr.getValues()){
            AnnotationClassElem classElem = (AnnotationClassElem) classFilter;
            classNameFilter.add(classElem.getDesc());
        }
        //filter
        for(String className : candidates){
            scanClass sc = componentScanMap.get(className);
            List<annotation> annotations = sc.getClassAnnotations();
            for(annotation a : annotations){
                boolean contains = classNameFilter.contains(a.getName());
                if((contains && isIncludeFilter) || (!contains && !isIncludeFilter)){
                    res.add(className);
                }
            }
        }
        return res;
    }

    /**
     * @param candidates
     * @param elem
     * @param isIncludeFilter
     * @return
     */
    private List<String> handleASSIGNABLEFilter(List<String> candidates,AnnotationElem elem,boolean isIncludeFilter){
        AnnotationArrayElem arr = (AnnotationArrayElem) elem;
        List<String> classNameFilter = new ArrayList<>();
        for(AnnotationElem classFilter : arr.getValues()){
            AnnotationClassElem classElem = (AnnotationClassElem) classFilter;
            String name = handleClassName(classElem.getDesc());
            name = name.replace("/",".");
            classNameFilter.add(name);
        }

        List<String> res = new ArrayList<>();
        for(String className : candidates){
            scanClass sc = componentScanMap.get(className);
            Chain<SootClass> interfaces = sc.getInterfaces();
            SootClass superClass = sc.getSuperClass();
            //父类or接口
            boolean contains = false;
            if(classNameFilter.contains(superClass.getName())){
                contains = true;
                classNameFilter.add(superClass.getName());
            }
            for(SootClass sootInterface : interfaces){
                if(classNameFilter.contains(sootInterface.getName())){
                    contains = true;
                }
            }
            if((contains && isIncludeFilter) || (!contains && !isIncludeFilter)){
                res.add(className);
            }
        }
        return res;
    }

    /**
     * @param candidates
     * @param elem
     * @param isIncludeFilter
     * @return
     */
    private List<String> handleASPECTJFilter(List<scanClass> candidates,AnnotationElem elem,boolean isIncludeFilter){
        AnnotationArrayElem arr = (AnnotationArrayElem) elem;
        List<String> res = new ArrayList<>();
        for(AnnotationElem classFilter : arr.getValues()){
            AnnotationStringElem stringElem = (AnnotationStringElem) classFilter;
            String pattern = stringElem.getValue();
            for(scanClass sc : AspectPathMatcher.classPatternMatcher(candidates,pattern)){
                res.add(sc.getName());
            }
        }
        if(isIncludeFilter){
            return res;
        }
        else{
            List<String> list = new ArrayList<>();
            for(scanClass sc : candidates){
                if(!res.contains(sc.getName())){
                    list.add(sc.getName());
                }
            }
            return list;
        }
    }

    /**
     * @param candidates
     * @param elem
     * @param isIncludeFilter
     * @return
     */
    private List<String> handleREGEXFilter(List<String> candidates,AnnotationElem elem,boolean isIncludeFilter){
        AnnotationArrayElem arr = (AnnotationArrayElem) elem;
        List<String> res = new ArrayList<>();
        for(AnnotationElem patterns : arr.getValues()){
            String pattern = ((AnnotationStringElem) patterns).getValue();
            Pattern p = Pattern.compile(pattern);
            for(String s : candidates){
                Matcher matcher = p.matcher(s);
                boolean matches = matcher.matches();
                if((matches && isIncludeFilter) || (!matches && !isIncludeFilter)){
                    res.add(s);
                }
            }
        }
        return res;
    }
}
