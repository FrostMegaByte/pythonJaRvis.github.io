package IOC.bean;

import base.config.Config;
import base.util.CountUtil;
import base.util.JsonUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanField;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.AbstractNode;
import edu.fdu.se.callgraph.impurity.bean.Node;
import soot.SootClass;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationStringElem;

import java.util.*;

public class UsedBeanScanner {

    private List<scanClass> scanClasses;
    private List<scanClass> usedBeanClasses = new ArrayList<>();
    private List<Bean> allBeans;
    private List<scanField> allFields = new ArrayList<>();
    private Map<scanClass,List<scanField>> fieldMap = new HashMap<>();
    private double time = 0;

    public UsedBeanScanner(List<scanClass> scanClasses,List<Bean> allBeans){
        this.scanClasses = scanClasses;
        this.allBeans = allBeans;
    }

    public double getTime(){
        return this.time;
    }

    /**
     * @Autowired @Resource @Qualifier @Primary
     */
    public void scanUseBeanClasses(){
        for(scanClass sc : scanClasses){
            List<scanField> fields = sc.getScanFields();
            for(scanField field : fields){
                List<annotation> annotations = field.getFieldAnnotations();
                for(annotation a : annotations){
                    if(a.getName().equals("Lorg/springframework/beans/factory/annotation/Autowired;")
                    || a.getName().equals("Ljavax/annotation/Resource;")){
                        usedBeanClasses.add(sc);
                    }
                }
            }
        }
    }

    /**
     */
    public void handleUseBeanClasses(){
        for(scanClass sc : usedBeanClasses){
            fieldMap.put(sc,new ArrayList<>());
            for(scanField field :sc.getScanFields()){
                List<annotation> annotations = field.getFieldAnnotations();
                boolean isAutowired = false,isQualifier = false;
                annotation qualifier = null;
                for(annotation a : annotations){
                    if(a.getName().equals("Lorg/springframework/beans/factory/annotation/Autowired;")){
                        isAutowired = true;
                    }
                    else if(a.getName().equals("Lorg/springframework/beans/factory/annotation/Qualifier;")){
                        isQualifier = true;
                        qualifier = a;
                    }
                    else if(a.getName().equals("Ljavax/annotation/Resource;")){
                        handleResource(a,field,sc);
                    }
                }
                if(isAutowired) handleAutowired(qualifier,field,isQualifier,sc);
            }
        }
    }

    /**
     * @param a
     * @param field
     */
    private void handleAutowired(annotation a,scanField field,boolean isQualifier,scanClass sc){
        String name = "";
        if(isQualifier){
            for(AnnotationElem elem : a.getParams()){
                if(elem.getName().equals("value")){
                    name = ((AnnotationStringElem) elem).getValue();
                }
            }
        }
        for(Bean bean : allBeans){
            if(isQualifier){
                if(bean.getBeanName().equals(name)){
                    field.setFieldType(bean.getBeanType());
                }
            }
            else{
                if(bean.getBeanType().equals(field.getFieldType()) && bean.isPrimary()){
                    field.setFieldType(bean.getBeanType());
                }
            }
        }
        allFields.add(field);
        fieldMap.get(sc).add(field);
    }

    /**
     * @param a
     * @param field
     */
    private void handleResource(annotation a,scanField field,scanClass sc){
        boolean byName = false,byType = false;
        String name = "",type = "";
        for(AnnotationElem elem : a.getParams()){
            if(elem.getName().equals("name")){
                byName = true;
                name = ((AnnotationStringElem) elem).getValue();
            }
            else if(elem.getName().equals("type")){
                byType = true;
                type = ((AnnotationStringElem) elem).getValue();
            }
        }
        for(Bean bean : allBeans){
            String beanType = bean.getBeanType();
            String beanName = bean.getBeanName();
            if(byName && byType){
                if(beanType.equals(type) && beanName.equals(name)){
                    field.setFieldType(type);
                }
            }
            else if(byName){
                if(beanName.equals(name)){
                    field.setFieldType(type);
                }
            }
            else if(beanType.equals(type)){
                field.setFieldType(type);
            }
        }
        allFields.add(field);
        fieldMap.get(sc).add(field);
    }

    public List<scanField> getAllFields(){
        return this.allFields;
    }

    /**
     * @param path
     */
    public void writeIntoJson(String path){
        Map<String, JSONArray> map = new HashMap<>();
        map.put("Autowired",new JSONArray());
        map.put("Resource",new JSONArray());
        map.put("Qualifier",new JSONArray());
        for(scanField field : allFields){
            for(annotation a : field.getFieldAnnotations()){
                JSONObject object = new JSONObject(new LinkedHashMap<>());
                object.put("fieldClassName",field.getClassName());
                object.put("fieldName",field.getFieldName());
                object.put("fieldType",field.getFieldType());
                if(a.getName().equals("Lorg/springframework/beans/factory/annotation/Autowired;")){
                    map.get("Autowired").add(object);
                }
                else if(a.getName().equals("Ljavax/annotation/Resource;")){
                    map.get("Resource").add(object);
                } else if(a.getName().equals("Lorg/springframework/beans/factory/annotation/Qualifier;")){
                    map.get("Qualifier").add(object);
                }
            }
        }
        JSONArray array = new JSONArray();
        for(String annotation : map.keySet()){
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("annotationName",annotation);
            jsonObject.put("sum",map.get(annotation).size());
            jsonObject.put("list",map.get(annotation));
            array.add(jsonObject);
        }
        JsonUtil.writeJson(path,array,true);
    }

    /**
     * @param callGraphMain
     * @param map
     * @return
     */
    public List<Node> getUnusedNodes(CallGraphMain callGraphMain, Map<String,scanClass> map){
        long start = System.currentTimeMillis();
        int[] res = new int[2];
        JSONArray arr = new JSONArray();
        List<Node> unused = new ArrayList<>();
        for(scanClass sc : usedBeanClasses){
            List<scanField> fields = fieldMap.get(sc);
            boolean isModified = false;
            for(scanField field : fields){
                if(field.getModified()){
                    isModified = true;
                }
            }
            if(!isModified){
                continue;
            }
            for(scanMethod sm : sc.getScanMethods()){
                arr.add(sm.getMethodFullName());
            }
            CallGraphBean callGraphBean = callGraphMain.generateCallGraph(arr, Config.JAR_PATH);
            List<Node> roots = callGraphBean.getCiaMethod();
            for(Node root : roots){
                if(root.getChildren() == null || root.getChildren().size() == 0){
                    continue;
                }
                for(scanField field : fields){
                    String realType = field.getFieldType();
                    String type = field.getOriginalType();
                    for(AbstractNode child : root.getChildren()){
                        SootClass sootClass = ((Node) child).getMethod().getDeclaringClass();
                        if(!map.containsKey(sootClass.getName())){
                            continue;
                        }
                        scanClass scannedClass = map.get(sootClass.getName());
                        String className = scannedClass.getName();
                        List<String> interfaceNames = scannedClass.getInterfaceNames();
                        List<String> parents = scannedClass.getParents();
                        boolean isType = false;
                        if(className.contains(type)){
                            isType = true;
                        }
                        for(String interfaceName : interfaceNames){
                            if(interfaceName.contains(type)){
                                isType = true;
                            }
                        }
                        for(String parent : parents){
                            if(parent.contains(type)){
                                isType = true;
                            }
                        }
                        if(isType && !className.contains(realType)){
                            unused.add((Node)child);
                        }
                    }
                }
            }
        }
        long end = System.currentTimeMillis();
        this.time += (double)(end - start) / 60000;
        return unused;
    }

    public List<scanClass> getUsedBeanClasses(){
        return this.usedBeanClasses;
    }
}
