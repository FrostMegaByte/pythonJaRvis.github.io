package IOC.bean;

import base.config.Config;
import base.util.CountUtil;
import base.util.JsonUtil;
import base.util.PropertyUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanField;
import dataStructure.scanMethod;
import edu.fdu.se.callgraph.CallGraphMain;
import edu.fdu.se.callgraph.dataclass.CallGraphBean;
import edu.fdu.se.callgraph.impurity.bean.AbstractNode;
import edu.fdu.se.callgraph.impurity.bean.Node;
import soot.SootClass;
import soot.tagkit.AnnotationArrayElem;
import soot.tagkit.AnnotationClassElem;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationStringElem;

import java.util.*;

public class BeanScanner {
    private List<scanClass> scanClassesWithBean = new ArrayList<>();
    private Map<String,BeanConstructor> classNameWithBeans = new HashMap<>();
    private List<scanClass> controllerClasses = new ArrayList<>();
    List<Bean> allBeans = new ArrayList<>();
    List<scanClass> classes;
    private Map<String,List<String>> annotationMap;
    private List<Bean> controllerBeans = new ArrayList<>();


    public BeanScanner(List<scanClass> scanClasses,List<scanClass> allClasses,Map<String,List<String>> annotationMap){
        for(scanClass sc : scanClasses){
            if(sc != null){
                scanClassesWithBean.add(sc);
            }
        }
        this.classes = allClasses;
        this.annotationMap = annotationMap;
    }

    /**
     * @Service @Controller @Repository @Configuration
     */
    public void BeanScannerHandler(String path) throws Exception{
        List<scanClass> componentClasses = new ArrayList<>();
        List<scanClass> configurationClasses = new ArrayList<>();
        for(scanClass sc : scanClassesWithBean){
            for(annotation a : sc.getClassAnnotations()){
                if(a.getName().equals("Lorg/springframework/context/annotation/Import;")){
                    handleImportAnnotation(a,sc);
                } else if(a.getName().equals("Lorg/springframework/context/annotation/Configuration;")){
                    configurationClasses.add(sc);
                } else{
                    if(a.getName().equals("Lorg/springframework/web/bind/annotation/RestController;") ||
                            a.getName().equals("Lorg/springframework/stereotype/Controller;") ||
                            a.getName().equals("Lorg/springframework/web/bind/annotation/ControllerAdvice;") ||
                            a.getName().equals("Lorg/springframework/web/bind/annotation/RestControllerAdvice;")){
                        controllerClasses.add(sc);
                    }
                    componentClasses.add(sc);
                }
            }
        }
        for(scanClass sc : componentClasses){
            BeanConstructor bc = new BeanConstructor(sc,allBeans,classes,annotationMap);
            bc.scanBeanClass();
            classNameWithBeans.put(sc.getName(),bc);
            allBeans.addAll(bc.beans);
        }
        for(scanClass sc : configurationClasses){
            BeanConstructor bc = new BeanConstructor(sc,allBeans,classes,annotationMap);
            bc.scanBeanClass();
            classNameWithBeans.put(sc.getName(),bc);
            allBeans.addAll(bc.beans);
        }
    }

    /**
     * @param a
     */
    private void handleImportAnnotation(annotation a,scanClass sc){
        List<AnnotationElem> params = a.getParams();
        for(AnnotationElem param : params){
            AnnotationArrayElem classes = (AnnotationArrayElem) param;
            for(AnnotationElem className : classes.getValues()){
                //Lcom/example/demo/Demo1Application; 需要处理 搜索很麻烦
                String name = ((AnnotationClassElem) className).getDesc();
                String newName = handleClassName(name).replace("/",".");
                for(scanClass csc : scanClassesWithBean){
                    if(csc.getName().contains(newName)){
                        BeanConstructor constructor = new BeanConstructor(csc,allBeans,this.classes,annotationMap);
                        constructor.scanBeanClass();
                        classNameWithBeans.put(sc.getName(),constructor);
                        allBeans.addAll(constructor.beans);
                    }
                }
            }
        }
    }

    /**
     * @param className
     * @return
     */
    private String handleClassName(String className){
        return className.substring(1,className.length() - 1);
    }

    public void writeIntoJson(String path){
        JSONArray arr = new JSONArray();
        for(Bean bean : allBeans){
            JSONObject beanObject = new JSONObject(new LinkedHashMap<>());
            beanObject.put("beanName",bean.getBeanName());
            beanObject.put("beanType",bean.getBeanType());
            beanObject.put("className",bean.getConstructorMethod().getScanClass().getName());
            beanObject.put("methodName",bean.getConstructorMethod().getName());
            beanObject.put("annotationName",bean.getAnnotationName());
            arr.add(beanObject);
        }
        JsonUtil.writeJson(path,arr,true);
    }

    public List<Bean> getAllBeans(){
        return allBeans;
    }

    public void filter() throws Exception{
        String environment = (String)PropertyUtil.read(Config.PROPERTY_PATH,"spring.profiles.active");
        if(environment == null) return;
        List<Bean> beans = new ArrayList<>();
        for(Bean bean : this.allBeans){
            if(bean.getEnvironment() != null && bean.getEnvironment().equals(environment)){
                beans.add(bean);
            }
        }
        this.allBeans = beans;
    }

    /**
     * @return
     */
    public List<Node> getMethodCount(CallGraphMain callGraphMain){
        JSONArray arr = new JSONArray();
        for(Bean bean : allBeans){
            arr.add(bean.getConstructorMethod().getMethodFullName());
            for(scanMethod sm : bean.getMethodChildren()){
                arr.add(sm.getMethodFullName());
            }
        }
        CallGraphBean callGraphBean = callGraphMain.generateCallGraph(arr,Config.JAR_PATH);
        return callGraphBean.getCiaMethod();
    }

    public List<scanClass> getControllerClasses(){
        return this.controllerClasses;
    }
}
