package IOC.bean;

import dataStructure.annotation;
import dataStructure.scanClass;
import dataStructure.scanMethod;
import soot.SootClass;
import soot.tagkit.AnnotationArrayElem;
import soot.tagkit.AnnotationClassElem;
import soot.tagkit.AnnotationElem;
import soot.tagkit.AnnotationStringElem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BeanConstructor {
    List<Bean> beans = new ArrayList<>();
    Map<String,Bean> beansConstructorNameMap = new HashMap<>();

    private scanClass beanClass;
    List<Bean> allBeans;
    List<scanClass> classes;
    private Map<String,List<String>> annotationMap;
    public BeanConstructor(scanClass sc,List<Bean> allBeans,List<scanClass> classes,Map<String,List<String>> annotationMap){
        this.beanClass = sc;
        this.allBeans = allBeans;
        this.classes = classes;
        this.annotationMap = annotationMap;
    }

    /**
     */
    public void scanBeanClass(){
        List<annotation> classAnnotations = beanClass.getClassAnnotations();
        if(classAnnotations.size() == 0){
            handleImportConstructor();
            return;
        }
        for(annotation a : classAnnotations){
            if(a.getName().equals("Lorg/springframework/stereotype/Component;") ||
                    a.getName().equals("Lorg/springframework/stereotype/Service;") ||
                    a.getName().equals("Lorg/springframework/stereotype/Repository;") ||
                    a.getName().equals("Lorg/springframework/web/bind/annotation/RestController;") ||
                    a.getName().equals("Lorg/springframework/stereotype/Controller;") ||
                    a.getName().equals("Lorg/springframework/context/annotation/Configuration;") ||
                    a.getName().equals("Lorg/springframework/web/bind/annotation/ControllerAdvice;") ||
                    a.getName().equals("Lorg/springframework/web/bind/annotation/RestControllerAdvice;")){
                handleComponentConstructor(a);
            }
            else if(a.getName().equals("Lorg/springframework/context/annotation/Configuration;")){
                handleConfigurationConstructor(a);
            } else if(annotationMap.containsKey("Lorg/springframework/stereotype/Component;")){
                for(String s : annotationMap.get("Lorg/springframework/stereotype/Component;")){
                    if(s.contains(getAnnotationName(a.getName()))){
                        handleComponentConstructor(a);
                    }
                }
            }
        }

        for(scanMethod sm : beanClass.getScanMethods()){
            for(annotation a : sm.getMethodAnnotations()){
                if(a.getName().equals("Ljavax/annotation/PostConstruct;") || a.getName().equals("Ljavax/annotation/PreAuthority;")){
                    for(Bean bean : beans){
                        bean.addMethodChild(sm);
                    }
                }
            }
        }
    }

    public String getAnnotationName(String name){
        String temp = name.substring(1,name.length() - 1);
        return temp.replace("/",".");
    }



    /**
     */
    private void handleImportConstructor(){
        Bean bean = new Bean();
        bean.setAnnotationName("Lorg/springframework/context/annotation/Import;");
        bean.setBeanType(beanClass.getName());
        bean.setBeanName(getBeanName(beanClass.getName()));
        List<scanMethod> scanMethods = beanClass.getScanMethods();
        for(scanMethod sm : scanMethods){
            if(sm.getName().equals("<init>")){
                bean.setConstructorMethod(sm);
            }
        }
        beans.add(bean);
        beansConstructorNameMap.put(bean.getConstructorMethod().getName(),bean);
    }

    /**
     * @param a
     */
    private void handleComponentConstructor(annotation a){
        for(annotation an : beanClass.getClassAnnotations()){
            if(isCondition(an) && !isMatches(an)){
                return;
            }
        }
        Bean bean = new Bean();
        bean.setAnnotationName(a.getName());
        bean.setBeanType(beanClass.getName());
        List<AnnotationElem> elems = a.getParams();
        if(elems == null || elems.size() == 0){
            bean.setBeanName(getBeanName(beanClass.getName()));
        }
        else{
            for(AnnotationElem elem : elems){
                if(elem instanceof AnnotationStringElem){
                    String beanName = ((AnnotationStringElem) elem).getValue();
                    bean.setBeanName(beanName);
                }
            }
        }
        List<scanMethod> scanMethods = beanClass.getScanMethods();
        for(scanMethod sm : scanMethods){
            if(sm.getName().equals("<init>")){
                bean.setConstructorMethod(sm);
            }
        }
        //primary & Profile
        for(annotation an : beanClass.getClassAnnotations()){
            if(an.getName().equals("Lorg/springframework/context/annotation/Primary;")){
                bean.setPrimary(true);
            }
            if(an.getName().equals("Lorg/springframework/context/annotation/Profile;")){
                for(AnnotationElem elem : an.getParams()){
                    for(AnnotationElem param : ((AnnotationArrayElem) elem).getValues()){
                        bean.setEnvironment(((AnnotationStringElem) param).getValue());
                    }
                }
            }
        }
        beans.add(bean);
        beansConstructorNameMap.put(bean.getConstructorMethod().getName(),bean);
    }

    /**
     * @param className
     * @return
     */
    private String getBeanName(String className){
        String[] str = className.split("\\.");
        className = str[str.length - 1];
        if(className.length() > 1 && Character.isUpperCase(className.charAt(0)) && Character.isUpperCase(className.charAt(1))){
            return className;
        }
        else{
            char[] chars = className.toCharArray();
            chars[0] = Character.toLowerCase(chars[0]);
            return new String(chars);
        }
    }

    /**
     * @Param a
     */
    private void handleConfigurationConstructor(annotation a){
        List<scanMethod> scanMethods = beanClass.getScanMethods();
        for(scanMethod sm : scanMethods){
            for(annotation at : sm.getMethodAnnotations()){
                if(isCondition(at) && !isMatches(at)){
                    return;
                }
                if(at.getName().equals("Lorg/springframework/context/annotation/Bean;")){
                    Bean bean = new Bean();
                    bean.setAnnotationName(at.getName());
                    bean.setBeanType(sm.getReturnType());
                    bean.setConstructorMethod(sm);
                    //primary
                    for(annotation an : sm.getMethodAnnotations()){
                        if(an.getName().equals("Lorg/springframework/context/annotation/Primary;")){
                            bean.setPrimary(true);
                        }
                        if(an.getName().equals("Lorg/springframework/context/annotation/Profile;")){
                            for(AnnotationElem elem : an.getParams()){
                                for(AnnotationElem param : ((AnnotationArrayElem) elem).getValues()){
                                    bean.setEnvironment(((AnnotationStringElem) param).getValue());
                                }
                            }
                        }
                    }
                    if(at.getParams().size() != 0){
                        for(AnnotationElem elem : at.getParams()){
                            for(AnnotationElem value : ((AnnotationArrayElem) elem).getValues()){
                                bean.setBeanName(((AnnotationStringElem) value).getValue());
                            }
                        }
                    }
                    else{
                        bean.setBeanName(sm.getName());
                    }
                    beans.add(bean);
                    beansConstructorNameMap.put(bean.getConstructorMethod().getName(),bean);
                }
            }
        }
    }

    public List<Bean> getBeans(){
        return this.beans;
    }

    /**
     * ConditionalOnBean ConditionalOnMissingBean ConditionalOnClass ConditionalOnMissingClass
     * @param a
     * @return
     */
    public boolean isMatches(annotation a){
        List<String> names = getParams(a);
        if(a.getName().equals("Lorg/springframework/boot/autoconfigure/condition/ConditionalOnBean;")){
            int count = 0;
            for(String name : names){
                for(Bean bean : allBeans){
                    if(bean.getBeanType().contains(name)){
                        count++;
                    }
                }
            }
            if(count == names.size()){
                return true;
            } else{
                return false;
            }
        } else if(a.getName().equals("Lorg/springframework/boot/autoconfigure/condition/ConditionalOnMissingBean;")) {
            int count = names.size();
            for(String name : names){
                for(Bean bean : allBeans){
                    if(bean.getBeanType().contains(name)){
                        count--;
                    }
                }
            }
            if(count == 0){
                return true;
            } else{
                return false;
            }
        } else if(a.getName().equals("Lorg/springframework/boot/autoconfigure/condition/ConditionalOnClass;")) {
            int count = 0;
            for (String name : names) {
                for (scanClass sc : classes) {
                    if (sc.getName().contains(name)) {
                        count++;
                    }
                }
            }
            if (count == names.size()) {
                return true;
            } else {
                return false;
            }
        } else if(a.getName().equals("Lorg/springframework/boot/autoconfigure/condition/ConditionalOnMissingClass;")) {
            int count = names.size();
            for (String name : names) {
                for (scanClass sc : classes) {
                    if (sc.getName().contains(name)) {
                        count--;
                    }
                }
            }
            if (count == 0) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    private List<String> getParams(annotation a){
        List<String> res = new ArrayList<>();
        for(AnnotationElem elem : a.getParams()){
            for(AnnotationElem param : ((AnnotationArrayElem) elem).getValues()){
                if(param instanceof AnnotationClassElem){
                    String desc = ((AnnotationClassElem) param).getDesc();
                    res.add(desc.replace("/",".").substring(1,desc.length() - 1));
                } else if(param instanceof AnnotationStringElem){
                    if(param instanceof AnnotationArrayElem){
                        for(AnnotationElem p : ((AnnotationArrayElem) param).getValues()){
                            res.add(((AnnotationStringElem) p).getValue());
                        }
                    } else{
                        res.add(((AnnotationStringElem) param).getValue());
                    }
                }
            }
        }
        return res;
    }

    public boolean isCondition(annotation a){
        String annotationName = a.getName();
        if(annotationName.contains("ConditionalOnBean") || annotationName.contains("ConditionalOnMissingBean")
        || annotationName.contains("ConditionalOnClass") || annotationName.contains("ConditionalOnMissingClass")){
            return true;
        } else{
            return false;
        }
    }
}
