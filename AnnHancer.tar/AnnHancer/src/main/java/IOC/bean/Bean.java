package IOC.bean;

import dataStructure.scanClass;
import dataStructure.scanMethod;

import java.util.ArrayList;
import java.util.List;

public class Bean {
    private String beanName;
    private String beanType;

    private boolean primary;

    private String environment;

    private scanMethod constructorMethod;

    private String annotationName;

    private List<Bean> parents = new ArrayList<>();

    private List<Bean> children = new ArrayList<>();

    private List<scanMethod> methodChildren = new ArrayList<>();

    public Bean(){}

    public void setBeanName(String beanName){
        this.beanName = beanName;
    }

    public void setBeanType(String beanType){
        this.beanType = beanType;
    }

    public void setPrimary(boolean isPrimary){
        this.primary = isPrimary;
    }

    public void setConstructorMethod(scanMethod constructorMethod){
        this.constructorMethod = constructorMethod;
    }

    public void setAnnotationName(String annotationName){
        this.annotationName = annotationName;
    }

    public scanMethod getConstructorMethod(){
        return this.constructorMethod;
    }

    public String getBeanName(){
        return this.beanName;
    }

    public String getBeanType(){
        return this.beanType;
    }

    public void addMethodChild(scanMethod sm){
        this.methodChildren.add(sm);
    }

    public List<scanMethod> getMethodChildren(){
        return this.methodChildren;
    }

    public boolean isPrimary(){
        return this.primary;
    }

    public String getAnnotationName(){
        return this.annotationName;
    }

    public scanClass getScanClass(){
        return this.constructorMethod.getScanClass();
    }

    public void setEnvironment(String environment){
        this.environment = environment;
    }

    public String getEnvironment(){
        return this.environment;
    }
}

