public class test {
    //IOC 15/25
    /*
     * IOC Constructor
     * @Service @Component @Repository @Import @Configuration @Bean
     */
    //case 1 @Component 
    //case 2 @Bean
    @Bean
    public RedisCacheConfiguration redisCacheConfiguration(){
        FastJsonRedisSerializer<Object> fastJsonRedisSerializer = new FastJsonRedisSerializer<>(Object.class);
        RedisCacheConfiguration configuration = RedisCacheConfiguration.defaultCacheConfig();
        configuration = configuration.serializeValuesWith(RedisSerializationContext.
                SerializationPair.fromSerializer(fastJsonRedisSerializer)).entryTtl(Duration.ofHours(2));
        return configuration;
    }
    //case 3 @Import
    @Import(BladeSentinelFilterConfiguration.class)
    @AutoConfigureBefore(SentinelFeignAutoConfiguration.class)
    public class BladeCloudAutoConfiguration {
    }

    /*
     * IOC Bean Call Graph
     * @Primary @DependsOn @PostConstruct @PreDestory
     */
    //case 1 @DependsOn on class or method
    //case 2 @Component class with @Autowired
    @Component
    public class UserMapperImpl implements UserMapper {

    @Autowired
    private RoleMapper roleMapper;
    }
    //case 3 @PostConstruct
    @PostConstruct
    private void initConfig() {
        setAuthenticationCachingEnabled(false);
        setAuthorizationCachingEnabled(true);
        setCachingEnabled(true);
        setCacheManager(redisCacheManager == null ? ehCacheManager : redisCacheManager);
    }
    //case 4 @PreDestory

    /*
     * IOC Dependency Injection
     * @Autowired @Qualifier @Resource @Primary
     */
    //case 1 @Autowired
    @Autowired
    private RoleMapper roleMapper;
    //case 2 @Resource
    @Resource
    private Scheduler scheduler;
    //case 3 @Autowired with @Qualifier
    @Autowired
	@Qualifier("flowRuleDefaultProvider")
	private DynamicRuleProvider<List<FlowRuleEntity>> ruleProvider;

    //AOP 7/15
    /*
     * AOP
     * @AspectJ @PointCut 
     * @Before @After @AfterReturning @AfterThrowing @Around
     */
    //case
    @Pointcut("@annotation(me.zhengjie.annotation.Limit)")
    public void pointcut() {
    }

    @Around("pointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        HttpServletRequest request = RequestHolder.getHttpServletRequest();
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method signatureMethod = signature.getMethod();
        Limit limit = signatureMethod.getAnnotation(Limit.class);
        LimitType limitType = limit.limitType();
        String key = limit.key();
        if (StringUtils.isEmpty(key)) {
            if (limitType == LimitType.IP) {
                key = StringUtils.getIp(request);
            } else {
                key = signatureMethod.getName();
            }
        }

        ImmutableList<Object> keys = ImmutableList.of(StringUtils.join(limit.prefix(), "_", key, "_", request.getRequestURI().replace("/","_")));

        String luaScript = buildLuaScript();
        RedisScript<Number> redisScript = new DefaultRedisScript<>(luaScript, Number.class);
        Number count = redisTemplate.execute(redisScript, keys, limit.count(), limit.period());
        if (null != count && count.intValue() <= limit.count()) {
            logger.info("第{}次访问key为 {}，描述为 [{}] 的接口", count, keys, limit.name());
            return joinPoint.proceed();
        } else {
            throw new BadRequestException("访问次数受限制");
        }
    }
    
    //MVC 11/11
    /*
     * MVC Controller
     * @Controller @RestController @RequestMapping @GetMapping @PostMapping @DeleteMapping @PutMapping @PatchMapping
     */
    @ApiOperation("导出部门数据")
    @GetMapping(value = "/download")
    @PreAuthorize("@el.check('dept:list')")
    public void exportDept(HttpServletResponse response, DeptQueryCriteria criteria) throws Exception {
        deptService.download(deptService.queryAll(criteria, false), response);
    }

    /*
     * MVC Exception handler
     * @ControllerAdvice @RestControllerAdvice @ExceptionHandler
     */
    @ExceptionHandler(Throwable.class)
    public ResponseEntity<ApiError> handleException(Throwable e){
        // 打印堆栈信息
        log.error(ThrowableUtil.getStackTrace(e));
        return buildResponseEntity(ApiError.error(e.getMessage()));
    }

    //Security 5/5
    /*
     * Security
     * @PostFilter @PreAuthorize @PreFilter @PostAuthorize @Secured
     */
    @ApiOperation("导出部门数据")
    @GetMapping(value = "/download")
    @PreAuthorize("@el.check('dept:list')")
    public void exportDept(HttpServletResponse response, DeptQueryCriteria criteria) throws Exception {
        deptService.download(deptService.queryAll(criteria, false), response);
    }

    //ConditionOn 17/17
    /*
     * ConditionOn
     * 
     */
    @Bean
	@ConditionalOnMissingBean
	public BlockExceptionHandler blockExceptionHandler() {
		return new BladeBlockExceptionHandler();
	}

    //valid 22/22
    /*
     * Valid
     */
    @Valid // 校验内嵌的字段
    @NotNull(message = "字段定义不能为空")
    private List<Column> columns;
}
